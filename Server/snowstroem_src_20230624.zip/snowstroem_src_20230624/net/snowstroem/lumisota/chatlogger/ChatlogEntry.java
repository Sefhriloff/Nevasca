package net.snowstroem.lumisota.chatlogger;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

/**
 * An immutable, preferably queued entry to be written in chatlog.
 *
 */
public final class ChatlogEntry {
	public final int userId;
	public final Timestamp moment;
	public final byte type;
	public final String content;

	public ChatlogEntry(final int u, final byte t, final String msg) {
		moment = new Timestamp(System.currentTimeMillis());
		userId = u;
		type = t;
		content = msg;

	}

	// ChatLogging SQL helper
	void fillEntry(final PreparedStatement ps) throws SQLException {
		ps.setInt(1, userId);
		ps.setTimestamp(2, moment);
		ps.setByte(3, type);
		ps.setString(4, content);

	}
}
