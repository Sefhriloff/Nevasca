package net.snowstroem.lumisota.chatlogger;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.Queue;

import net.snowstroem.lumisota.sql.Database;

/**
 * Collects and writes in-room chat into the database (SQL)
 *
 */
public final class ChatLogging {
	private final static String LOG_SQL = "INSERT INTO CHATLOG (ACCOUNTID, MOMENT, LOUDNESS, MESSAGE) VALUES (?, ?, ?, ?)";
	private final static Queue<ChatlogEntry> CHAT_QUEUE = new ArrayDeque<>();
	private ChatLogging() {}

	public static void flushQueue() {
		synchronized(CHAT_QUEUE) {
			if (!CHAT_QUEUE.isEmpty()) {
				Database.useConnection(conn -> {
					int entries = 0;
					boolean ac = true;
					try {
						ac = conn.getAutoCommit();
						conn.setAutoCommit(false);

					} catch (SQLException e) {
						e.printStackTrace();

					}
					try (final PreparedStatement ps = conn.prepareStatement(LOG_SQL)) {
						while (!CHAT_QUEUE.isEmpty()) {
							CHAT_QUEUE.remove().fillEntry(ps);
							ps.execute();
							entries++;

						}
					} catch (SQLException e) {
						e.printStackTrace();

					}
					try {
						conn.commit();
						conn.setAutoCommit(ac);

					} catch (SQLException e) {
						e.printStackTrace();

					}
					System.out.println("ChatLogging: logged " + entries + " lines");

				});
			}
		}
	}

	public static void addEntry(final ChatlogEntry e) {
		synchronized (CHAT_QUEUE) {
			CHAT_QUEUE.add(e);

		}
	}
}
