package net.snowstroem.lumisota;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Config file initialization actions
 * @author asc
 *
 */
public class LumisotaConfig {
	private static final byte[] DB_PROP = ("; Connection manager general setup\n" +
			"connectionLimit = 10\n" +
			"\n" +
			"; Settings to interface with h2\n" +
			"jdbcUrl = jdbc:h2:./lumidb\n" +
			"dbuser = SA\n" +
			"dbpass = \n")
			.getBytes(StandardCharsets.UTF_8);

	private static final byte[] LS_PROP = ("; Amount of core threads to have available at all times for the majority of command handling.\n" +
			"schedulerCores = 2\n" +
			"\n" +
			"; A secret sequence to expect with remote commands.\n" +
			"; If remoteBind is not localhost, you may want to set up a strong secret.\n" +
			"remoteSecret = \n" +
			"\n" +
			"; The interface that remote commands will be listened from.\n" +
			"; Only change from localhost if remote control is hosted elsewhere.\n" +
			"remoteBind = 127.0.0.1\n" +
			"\n" +
			"; The port that UDP queries are exchanged from.\n" +
			"remotePort = 55554\n" +
			"\n" +
			"; The port of the landscape server that handles registering and cottage listing.\n" +
			"landscapePort = 55555\n" +
			"\n" +
			"; Ports that cottage sockets will listen.\n" +
			"; Value can be:\n" +
			";   - Individual port, e.g. \"55556\" - This means only one cottage can be set up.\n" +
			";   - Port range, e.g. \"55556-55596\"\n" +
			";   - List of ports, e.g. \"55556,55557,55558,55559\"\n" +
			";   - Combination of the above, e.g. \"55556-55559,55565-55584\"\n" +
			"cottagePorts = 55556-55596\n" +
			"\n" +
			"; Cottage connections are established to this domain name or IP address.\n" +
			"cottageDomain = 127.0.0.1\n" +
			"\n" +
			"; Amount of cottages to boot when first starting the server.\n" +
			"; These run on separate server sockets on port(s) lanscapePort +1, (landscapePort +2, landscapePort +3...)\n" +
			"; The client requires at least one available cottage in order to display the landscape!\n" +
			"cottagesOnBoot = 1\n" +
			"\n" +
			"; Cottage name table: Comma separated.\n" +
			"; Cottages will either be named after these, have their name specified in the\n" +
			";   UDP command or fall back to using hardcoded \"Mökki #\" names.\n" +
			"cottageNames = Kevytlevi, Korvapuusti, Uimapallas, Vaatteetylläs, Outtakkatuli\n")
			.getBytes(StandardCharsets.UTF_8);

	public final static Path LS_CONF_P = FileSystems.getDefault().getPath("snowstroem.properties");
	public final static Path DB_CONF_P = FileSystems.getDefault().getPath("database.properties");

	static void create() {
		if (Files.notExists(LS_CONF_P)) {
			try {
				Files.write(LS_CONF_P, LS_PROP, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);

			} catch (IOException e) {
				e.printStackTrace();

			}
		}
		if (Files.notExists(DB_CONF_P)) {
			try {
				Files.write(DB_CONF_P, DB_PROP, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);

			} catch (IOException e) {
				e.printStackTrace();

			}
		}
	}
}
