package net.snowstroem.lumisota.remote;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import net.snowstroem.lumisota.Lumisota;

/**
 * Receiver for control commands over UDP socket
 *
 */
public final class UDPQueryHandler {
	@SuppressWarnings("resource")
	public static void process(String host, int port, final byte[] secretSequence) {
		try {
			final ByteBuffer req = ByteBuffer.allocate(secretSequence.length + 64);
			String resp = "NO";
			SocketAddress sa = null;
			SelectionKey key;
			final Selector selector = Selector.open();
			final DatagramChannel channel = DatagramChannel.open();
			channel.socket().bind(new InetSocketAddress(InetAddress.getByName(host), port));
			channel.configureBlocking(false).register(selector, SelectionKey.OP_READ);
			for(;;) {
				try {
					selector.select();
					Iterator<SelectionKey> selectedKeys = selector.selectedKeys().iterator();
					while (selectedKeys.hasNext()) {
						try {
							key = selectedKeys.next();
							selectedKeys.remove();
							if (key.isValid()) {
								if (key.isReadable()) {
									DatagramChannel chan = (DatagramChannel)key.channel();
									req.clear();
									sa = chan.receive(req);
									req.flip();
									boolean secretOk = true;
									for (byte s : secretSequence) {
										if (s != req.get()) {
											secretOk = false;
											break;

										}
									}
									resp = secretOk
											? Lumisota.handleQuery(req.get(), new String(req.array(), req.position(), req.remaining(), StandardCharsets.UTF_8))
													: "NO";
									key.interestOps(SelectionKey.OP_WRITE);

								} else if (key.isWritable()) {
									((DatagramChannel) key.channel()).send(ByteBuffer.wrap(resp.getBytes(StandardCharsets.UTF_8)), sa);
									key.interestOps(SelectionKey.OP_READ);

								}
							}
						} catch (Exception e) {
							System.err.println("UDP handling encountered exception");
							e.printStackTrace();

						}
					}
				} catch (IOException e) {
					System.err.println("UDPQueries: glitch, continuing... ");
					e.printStackTrace();

				}
			}
		} catch (IOException e) {
			System.err.println("UDP: uncaught error");
			e.printStackTrace();

		}
	}
}
