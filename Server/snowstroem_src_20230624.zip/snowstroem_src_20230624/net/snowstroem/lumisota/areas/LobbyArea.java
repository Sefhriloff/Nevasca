package net.snowstroem.lumisota.areas;

import java.util.stream.Stream;

import net.snowstroem.lumisota.areas.entities.ActiveEntity;
import net.snowstroem.lumisota.areas.entities.AreaClient;
import net.snowstroem.lumisota.areas.entities.InteractiveBot;
import net.snowstroem.lumisota.areas.entities.LobbyBot;
import net.snowstroem.lumisota.fuse.FuseServer;
import net.snowstroem.lumisota.fuse.ListenerCall;

/**
 * Interactive Area for casual chatting and setting up snowfights or messing with the bot to get hot chocolate
 *
 */
public class LobbyArea extends Area {
	private final LobbyBot bot;

	public LobbyArea(FuseServer server) {
		super(server, (byte) -1, 0);
		bot = new LobbyBot("Maunorvo", "7,7,1", "Koihihihivisto", this);
	}

	@Override
	public ListenerCall drawGameboard() {
		final ListenerCall games = new ListenerCall("GAMEBOARD");
		host.getGames().map(SnowfightArea::game).forEach(games::append);
		return games;
	}

	@Override
	public void disposeGameEvent(final AreaClient ac, final String data) { // UndoGame
		host.getGames()
		.filter(g -> g.gameOwner == ac.name)
		.findAny()
		.filter(g -> !g.ended && !g.started)
		.ifPresent(a -> host.closeArea(a.id));
	}

	@Override
	public void makeGameEvent(AreaClient ac, String data) { // CreateGame
		removeFromGame(ac);
		if (data.charAt(0) != '.') { // Reserve for .resign
			final String[] input = data.split(";");
			if (input.length == 4) {
				final String gName = input[0].replace('/', '\\'); // Must not use the item delimiter
				if (host.getGames().noneMatch(g -> g.gameOwner == ac.name || gName.equalsIgnoreCase(g.name))) { // May only host one, non-duplicate-name game at a time
					byte mins = 0, bCount = 0;
					try {
						mins = Byte.parseByte(input[1]);
						bCount = Byte.parseByte(input[2]);
					} catch (NumberFormatException nfe) {
						return;
					}
					host.newGame(gName, mins, bCount, ac.name, input[3].equals("red"));
				}
			}
		}
		broadcast(drawGameboard());
	}

	@Override
	public void joinGameEvent(AreaClient ac, String data) { // JoinGame
		removeFromGame(ac);
		if (data.charAt(0) != '.') { // Reserve for .resign
			final String[] input = data.split(";");
			if (input.length == 2) {
				host.getGame(input[0])
				.ifPresent(a -> a.addToGame(ac.name, input[1].equals("red")));
			}
		}
		broadcast(drawGameboard());
	}

	@Override
	public void positionClient(final AreaClient ac, final boolean alternative) {
		if (alternative) {
			ac.x = 0;
			ac.y = 1;
			ac.z = ac.hdRot = ac.bdRot = 2;

		} else {
			ac.x = 13;
			ac.y = 19;
			ac.z = ac.hdRot = ac.bdRot = 0;
		}
	}

	@Override
	public void beginGameEvent(AreaClient ac, String data) { // StartGame
		host.getGame(data).ifPresent(g -> g.beginGameEvent(ac, null));
	}

	@Override
	protected long getTick() {
		return 450L;
	}

	@Override
	protected Stream<ActiveEntity> getUpdateables() {
		return Stream.of(bot);
	}

	@Override
	public void removeFromGame(final AreaClient ac) {
		host.getGames().forEach(a -> a.removeFromGame(ac));
	}

	@Override
	protected Stream<InteractiveBot> getBots() {
		return Stream.of(bot);
	}
}
