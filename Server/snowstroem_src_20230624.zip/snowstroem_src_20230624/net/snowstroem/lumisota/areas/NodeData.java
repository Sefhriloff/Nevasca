package net.snowstroem.lumisota.areas;

import java.util.Optional;

import net.snowstroem.lumisota.areas.entities.AreaObject;
import net.snowstroem.lumisota.areas.entities.Avatar;

/**
 * NodeData contains height value and occupants of a square inside an {@link Area}
 *
 */
public final class NodeData {

	/**
	 * The X coordinate this node is positioned in
	 */
	public final byte x;

	/**
	 * The Y coordinate this node is positioned in
	 */
	public final byte y;

	/**
	 * The height value on this node. If set to negative, this square cannot be used by entities
	 */
	public byte z;

	/**
	 * The Optional wrapped {@link Avatar} occupying this node
	 */
	public Optional<Avatar> entityOnTile;

	/**
	 * The Optional wrapped {@link AreaObject} occupying this node
	 */
	public Optional<AreaObject> objectOnTile;

	public NodeData(final int xC, final int yC) {
		x = (byte) xC;
		y = (byte) yC;
		z = 0;
		entityOnTile = Optional.empty();
		objectOnTile = Optional.empty();
	}

	public boolean free() {
			return z >= 0 && !objectOnTile.isPresent() && !entityOnTile.isPresent();
	}
}
