package net.snowstroem.lumisota.areas;

import static net.snowstroem.lumisota.parsing.ContentParsers.toFuseListener;

import java.text.DecimalFormat;
import java.util.ArrayDeque;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import net.snowstroem.lumisota.Lumisota;
import net.snowstroem.lumisota.areas.entities.ActiveEntity;
import net.snowstroem.lumisota.areas.entities.AreaClient;
import net.snowstroem.lumisota.areas.entities.InteractiveBot;
import net.snowstroem.lumisota.areas.entities.Snowball;
import net.snowstroem.lumisota.areas.entities.StatName;
import net.snowstroem.lumisota.areas.entities.StatState;
import net.snowstroem.lumisota.fuse.FuseServer;
import net.snowstroem.lumisota.fuse.ListenerCall;
import net.snowstroem.lumisota.parsing.ContentParsers;

/**
 * Interactive area for exchanging snowballs between players
 *
 */
public class SnowfightArea extends Area {
	/*
	 * Not the most accurate solution, stretching every game second by 20%, two reasons behind this:
	 *   - Client doesn't always count to 60 ticks within 1 second, skipping last second bleeps at times.
	 *   - gameStatus can be concatenated with regular status by ActiveEntity implementation
	 */
	private class StatusCounter implements ActiveEntity {
		private int ticksLeft;

		private StatusCounter(int mins) {
			ticksLeft = mins * 60 * 3;
		}

		@Override
		public boolean checkStatusUpdates() {
			if (started) {
				if (ticksLeft-- % 3 == 0) {
					if (ticksLeft == 2) {
						Lumisota.SCHEDULER.schedule(() -> {
							ended = true;
							statusBar = Optional.empty();
							snowballmachine = Optional.empty();
							final boolean nonDraw = redScore != greenScore;
							final boolean redWins = redScore > greenScore;
							final ListenerCall resultBoard = new ListenerCall("GAME_RESULTS")
									.append("red ").append(redScore).cr()
									.append("blue ").append(greenScore);
							mapMaxX = Maps.mapXDiameter(5);
							mapMaxY = Maps.mapYDiameter(5);
							squares = Maps.prepMap(5);
							synchronized(users) {
								for (AreaClient usr : users) {
									if (!bots) {
										usr.updateScores(nonDraw, redWins);

									}
									usr.clearPath();
									positionClient(usr, false);
									resultBoard.cr()
									.append(usr.name).ws()
									.append(usr.onRedTeam ? "red" : "blue").ws()
									.append(usr.enemykills).ws()
									.append(usr.friendlykills).ws()
									.append(usr.deaths).ws()
									.append(usr.points);

								}
							}
							resultBoard.append(bailOuts);
							broadcast(resultBoard);
							broadcast(Maps.HEIGHTMAPS[5]);
							broadcast(Maps.OBJMAPS[5]);
							broadcast(users.stream().map(AreaClient::usersEntry).collect(toFuseListener("USERS")));
							broadcast(users.stream().map(AreaClient::getStatus).collect(toFuseListener("STATUS")));
							Lumisota.SCHEDULER.schedule(() -> {
								try {
									for (AreaClient remaining : users.toArray(new AreaClient[users.size()])) {
										// Transfers induce removal, thus contents must be iterated in a copy
										if (remaining != null) remaining.transferTo(host.lobby, false);
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							}, 180, TimeUnit.SECONDS);
						}, 1, TimeUnit.SECONDS);
					}

					return true;
				}
			}

			return false;
		}

		@Override
		public CharSequence getStatus() {
			return "*gameStatus " +
					(ticksLeft / 3 / 60) + ':' + DOUBLE_DIGIT.format(ticksLeft / 3 % 60) + ' ' + // Time
					redScore + ' ' + greenScore + ' ' + // Team points
					(started && !ended) + ' ' + (ticksLeft <= 30); // Game running and game nearing ending
		}
	}

	private class SnowballSpawner implements ActiveEntity {
		private final static byte MACHINE_X1 = 26, MACHINE_X2 = 27, MACHINE_Y = 28;
		private int ticks = 0, contents = 0;

		@Override
		public boolean checkStatusUpdates() {
			if (ticks++ > 15) {
				ticks = 0;
				if (contents < 5) {
					contents++;
					return true;
				}
			}

			if (ticks % 5 == 0 && contents > 0) {
				return findByPosition(MACHINE_X1, MACHINE_Y).or(() -> findByPosition(MACHINE_X2, MACHINE_Y))
						.filter(a -> a instanceof AreaClient)
						.map(a -> (AreaClient) a)
						.filter(a -> {
							if (a.snowballs < (a.ballBonus() ? 7 : 5)) {
								contents--;
								a.addStat(StatName.CARRYSB, new StatState(Byte.toString(++a.snowballs), 1));
								a.refreshStats();
								return true;
							}

							return false;
						})
						.isPresent();
			}

			return false;
		}

		@Override
		public CharSequence getStatus() {
			return "*Ballmachine ".concat(Integer.toString(contents));
		}

	}

	private final static DecimalFormat DOUBLE_DIGIT = new DecimalFormat("00");
	/**
	 * The maximum amount of players that may join one game
	 */
	public final static byte MAX_PLAYERS = 8;
	private final String[] redTeam, greenTeam;
	private final AtomicInteger sbId;
	private final ArrayDeque<NodeData> spawnTiles; // addFirst/pollFirst red, addLast/pollLast green
	private Optional<StatusCounter> statusBar;
	private Optional<SnowballSpawner> snowballmachine;
	private final StringBuilder bailOuts;

	/**
	 * Indicates whether this game has bots in it so points will not be awarded
	 */
	public final boolean bots;

	public String gameOwner;

	/**
	 * Number of minutes (1-10) this game may last.
	 */
	public final byte minutes;

	/**
	 * Name of the game associated with this Area, for gameboard entries.
	 */
	public final String name;

	public short redScore, greenScore;

	public boolean started, ended, full;

	public SnowfightArea(FuseServer server, byte idNum, String gameName, int map, final byte mins, final byte botCnt, final String owner, boolean ownerRed) {
		super(server, idNum, map);
		sbId = new AtomicInteger(1);
		name = gameName;
		redTeam = new String[4];
		greenTeam = new String[4];
		minutes = mins;
		redScore = greenScore = 0;
		spawnTiles = new ArrayDeque<>(8);
		bailOuts = new StringBuilder();
		addToGame(gameOwner = owner, ownerRed);
		if (bots = botCnt > 0) {
			boolean botRedTeam = !ownerRed;
			for (int i = 1; i <= botCnt; i++) {
				addToGame("lumirobo" + i, botRedTeam);
				botRedTeam = !botRedTeam;
			}
		}

		statusBar = Optional.of(new StatusCounter(mins));
		snowballmachine = map == 3 ? Optional.of(new SnowballSpawner()) : Optional.empty(); // Enabled on lumisota2 map

		switch (mapNum) {
		case 3: { // lumisota2
			spawnTiles.addFirst(getNode(18, 9));
			spawnTiles.addFirst(getNode(21, 7));
			spawnTiles.addFirst(getNode(20, 10));
			spawnTiles.addFirst(getNode(22, 9));
			spawnTiles.addLast(getNode(39, 42));
			spawnTiles.addLast(getNode(33, 39));
			spawnTiles.addLast(getNode(34, 42));
			spawnTiles.addLast(getNode(36, 40));
			break;

		} case 4: { // lumisota3
			spawnTiles.addFirst(getNode(23, 8));
			spawnTiles.addFirst(getNode(20, 7));
			spawnTiles.addFirst(getNode(27, 10));
			spawnTiles.addFirst(getNode(19, 9));
			spawnTiles.addLast(getNode(31, 43));
			spawnTiles.addLast(getNode(35, 44));
			spawnTiles.addLast(getNode(38, 42));
			spawnTiles.addLast(getNode(34, 41));
			break;

		} default: break;
		}
	}

	private void changeScores(AreaClient hitter, AreaClient target) {
		final boolean hitRed = hitter.onRedTeam;
		final boolean targetRed = target.onRedTeam;
		if (hitRed && !targetRed) {
				hitter.enemykills++;
				hitter.points++;
				redScore++;
				target.deaths++;
				target.points--;
				greenScore--;

		} else if (!hitRed && targetRed) {
				hitter.enemykills++;
				hitter.points++;
				greenScore++;
				target.deaths++;
				target.points--;
				redScore--;

		} else {
			hitter.friendlykills++;
			hitter.points--;
			target.deaths++;
			target.points--;
			if (hitRed) {
				redScore -= 2;

			} else {
				greenScore -= 2;

			}
		}
	}

	@Override
	protected long getTick() {
		return 334L;
	}

	@Override
	protected Stream<ActiveEntity> getUpdateables() {
		return Stream.of(snowballmachine, statusBar).flatMap(Optional::stream);
	}

	public void addToGame(final String name, boolean forRed) {
		if (!full) {
			final String[] sft = forRed ? redTeam : greenTeam;
			for (int i = 0; i < sft.length; i++) {
				if (sft[i] == null) {
					sft[i] = name;
					full = Stream.concat(Stream.of(redTeam), Stream.of(greenTeam)).noneMatch(Objects::isNull);
					return;
				}
			}
		}
	}

	@Override
	public void beginGameEvent(AreaClient ac, String data) {
		if (gameOwner == ac.name && !ended) {
			full = true;
			for (String nm : redTeam) {
				if (nm != null && !nm.startsWith("lumirobo")) {
					host.lobby.findByUsername(nm).ifPresent(a -> {
						a.transferTo(this, true);
					});
				}
			}

			for (String nm : greenTeam) {
				if (nm != null && !nm.startsWith("lumirobo")) {
					host.lobby.findByUsername(nm).ifPresent(a -> {
						a.transferTo(this, false);
					});
				}
			}

			synchronized(users) {
				users.forEach(AreaClient::freeze);

			}
			Lumisota.SCHEDULER.schedule(() -> {
				synchronized(users) {
					for (AreaClient usr : users) {
						usr.addStat(StatName.XTRAS, new StatState(ContentParsers.xtras(usr.hitBonus(), usr.ballBonus(), usr.hitptBonus()), 1));
						usr.hitPoints = (byte) (usr.hitptBonus() ? 14 : 10);
						usr.addStat(StatName.PLAYERST, new StatState(usr.genStatus(), 2));
						usr.addStat(StatName.CARRYSB, new StatState(Byte.toString(usr.snowballs = (byte) (usr.ballBonus() ? 7 : 5)), 2));
						usr.refreshStats();

					}
				}
				started = true;
				broadcast(drawGameboard());
				host.lobby.broadcast(host.lobby.drawGameboard());
				Lumisota.SCHEDULER.schedule(() -> {
					synchronized(users) {
					users.forEach(AreaClient::unfreeze);

					}
					broadcast(drawGameboard());

				}, 1500, TimeUnit.MILLISECONDS);
			}, 5, TimeUnit.SECONDS);
		}
	}

	@Override
	public void disposeGameEvent(final AreaClient ac, final String data) { // ThrowSnowball
		if (ac.snowballs > 0 && ac.hitPoints > 1) {
			final String[] sbParams = data.split(" ", 3);
			if (sbParams.length == 3) {
				byte targetX = ac.x, targetY = ac.y;
				if (!sbParams[0].equals("auto")) {
					try {
						ac.lookTo(targetX = Byte.parseByte(sbParams[0]), targetY = Byte.parseByte(sbParams[1]));

					} catch (NumberFormatException nfe) {
						// Assumably invalid input
					}

				} else {
					final Optional<AreaClient> target = findByUsername(sbParams[1]);
					if (target.isPresent()) {
						targetX = target.get().x;
						targetY = target.get().y;
					}
				}

				final Snowball sb = new Snowball(sbId.getAndIncrement(), ac.x, ac.y, targetX, targetY, Byte.parseByte(sbParams[2]));
				ac.removeStat(StatName.THROWING);
				ac.freeze();
				ac.addStat(StatName.THROWING, new StatState.Triggering("", 2, ac::unfreeze));
				ac.addStat(StatName.CARRYSB, new StatState(Byte.toString(--ac.snowballs), 2));
				ac.refreshStats();
				broadcast(sb.throwingMessage());
				if (inBounds(sb.targetX, sb.targetY)) {
					Lumisota.SCHEDULER.schedule(() -> findByPosition(sb.targetX, sb.targetY)
							.filter(a -> a instanceof AreaClient)
							.map(a -> (AreaClient) a)
							.filter(a -> a.hitPoints > 1 && !a.postDeath && !ended)
							.ifPresent(a -> {
								broadcast(new ListenerCall("BALLHIT") // Announce getting hit
										.append(sb.id).ws()
										.append(a.name).ws()
										.append(sb.targetX).ws()
										.append(sb.targetY).ws()
										.append(0));
								if ((a.hitPoints -= ac.hitBonus() ? 4 : 2) <= 0) {
									a.freeze();
									a.hitPoints = 0;
									a.addStat(StatName.PLAYERST, new StatState.Switching(StatName.PLAYERST, a, 16, () -> a.genStatus(),
											() -> {
												a.unfreeze();
												a.postDeath = true;
												a.hitPoints = (byte) (a.hitptBonus() ? 14 : 10);
												return 20;

											}, () -> {
												a.postDeath = false;
												return 1;
											}));
									changeScores(ac, a);
									broadcast(new ListenerCall("BALLDEATH").append(a.name).ws().append((a.bdRot))); // Rotation corrected by dcr
									host.lobby.broadcast(host.lobby.drawGameboard());

								} else {
									a.addStat(StatName.PLAYERST, new StatState(a.genStatus(), 1));
								}

								a.refreshStats();
							}), sb.speed + 45, TimeUnit.MILLISECONDS);
				}
			}
		}
	}

	@Override
	public ListenerCall drawGameboard() {
		return new ListenerCall("STATUS")
				.append(statusBar.map(ActiveEntity::getStatus).orElse(""));
	}

	public CharSequence game() {
		StringBuilder gData = new StringBuilder(name);
		gData.append('/')
		.append(id).append(' ')
		.append(started).append(' ')
		.append(full).append(' ')
		.append(ended).append(' ')
		.append(getPlayerCount()).append(' ')
		.append(MAX_PLAYERS).append(' ')
		.append(gameOwner).append(' ')
		.append(minutes)
		.append("/* blue");
		if (started) gData.append(' ').append(greenScore);
		for (String n : greenTeam) {
			if (n != null) gData.append(' ').append(n);
		}

		gData.append("/* red");
		if (started) gData.append(' ').append(redScore);
		for (String n : redTeam) {
			if (n != null) gData.append(' ').append(n);
		}

		return gData.append('\r');
	}

	@Override
	public void joinGameEvent(AreaClient ac, String data) {
		// Future use as current addToGame?
	}

	@Override
	public void makeGameEvent(AreaClient ac, String data) { // MakeSnowball
		if (ac.hitPoints > 1 && !ac.hasStat(StatName.MAKESB) && ac.snowballs < (ac.ballBonus() ? 7 : 5)) {
			ac.freeze();
			ac.addStat(StatName.MAKESB, new StatState.Triggering("", 4, ac::acquireSnowball));
			ac.refreshStats();
		}
	}

	@Override
	public void positionClient(final AreaClient ac, final boolean alternative) {
		if (alternative) {
			final NodeData spawn = ac.onRedTeam ? spawnTiles.pollFirst() : spawnTiles.pollLast();
			if (spawn == null) {
				ac.x = ac.y = 16;

			} else {
				ac.x = spawn.x;
				ac.y = spawn.y;
			}

		} else {
			ac.x = 5;
			ac.y = 3;
		}

		ac.z = 0;
		ac.hdRot = ac.bdRot = 4;
	}

	@Override
	public void removeFromGame(final AreaClient ac) {
		if (!started && gameOwner == ac.name) {
			host.closeArea(id);
			return;

		}
		if (started && !ended) {
			ac.points = -10;
			if (bots) {
				ac.updateScores(false, !ac.onRedTeam);
			}
			bailOuts.append('\r')
			.append(ac.name).append(' ')
			.append(ac.onRedTeam ? "red" : "blue").append(' ')
			.append(ac.enemykills).append(' ')
			.append(ac.friendlykills).append(' ')
			.append(ac.deaths).append(' ')
			.append(ac.points);

		}
		for (int i = 0; i < 4; i++) {
			if (redTeam[i] == ac.name) {
				redTeam[i] = null;
				full = started;
				return;

			}
			if (greenTeam[i] == ac.name) {
				greenTeam[i] = null;
				full = started;
				return;

			}
		}
	}

	@Override
	protected Stream<InteractiveBot> getBots() {
		return Stream.empty();
	}
}
