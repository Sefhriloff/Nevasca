package net.snowstroem.lumisota.areas.entities;

/**
 * The name of an active status of an {@link Avatar}
 */
public enum StatName {
	CARRYD, CARRYSB, DANCE, DRINK, GIVED, MAKESB, MV, PLAYERST, SIT, STAND, TAKED, TALK, THROWING, XTRAS;

	@Override
	public String toString() {
		return name().toLowerCase();

	}
}
