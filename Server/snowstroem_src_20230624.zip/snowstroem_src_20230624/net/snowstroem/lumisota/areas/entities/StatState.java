package net.snowstroem.lumisota.areas.entities;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Queue;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * StatState contains additional data associated with {@code StatName} and determines when the status has timed out.
 *
 */
public class StatState {
	/**
	 * Properties associated with the stat
	 */
	public final String data;

	/**
	 * The amount of ticks this stat will last
	 */
	private int lifetimeTicks;

	public StatState(final String content, final int ttl) {
		data = content;
		lifetimeTicks = ttl;

	}

	public boolean timedOut() {
		return --lifetimeTicks < 0;

	}

	/**
	 * An endless variant of StatState where timing out never occurs. Must terminate manually.
	 */
	public static class Indefinite extends StatState {
		public Indefinite(String content) {
			super(content, 0);

		}

		@Override
		public boolean timedOut() {
			return false;

		}
	}

	/**
	 * A triggered variant of StatState where given {@code Runnable} runs when timing out.
	 */
	public static class Triggering extends StatState {
		public final Runnable trigger;

		/**
		 * Constructor for a trigger running StatState
		 * @param content Properties associated with the stat
		 * @param ttl The amount of ticks this stat will last
		 * @param trig The method to run upon timing out
		 */
		public Triggering(String content, int ttl, Runnable trig) {
			super(content, ttl);
			trigger = trig;

		}

		@Override
		public boolean timedOut() {
			if (super.timedOut()) {
				trigger.run();
				return true;

			}
			return false;

		}
	}

	/**
	 * A state changing variant of StatState where given new timeouts are placed and changes are applied from {@code IntSupplier}s every time a state's time-out is reached.
	 */
	public static class Switching extends StatState {
		private final StatName theStat;
		private final Avatar theClient;
		private final Supplier<String> nextState;
		private final Queue<IntSupplier> allTriggers;

		/**
		 * Constructor for a self mutating StatState
		 * @param thisStat The stat to apply to user
		 * @param thisClient The user whom to apply stats on
		 * @param ttl Time-out of the first state
		 * @param states State updates generator
		 * @param triggers The changes to apply on timing out along with new time-outs
		 */
		public Switching(StatName thisStat, Avatar thisClient, int ttl, Supplier<String> states, IntSupplier... triggers) {
			super(states.get(), ttl);
			theStat = thisStat;
			theClient = thisClient;
			nextState = states;
			allTriggers = new ArrayDeque<>(triggers.length);
			Collections.addAll(allTriggers, triggers);

		}

		private Switching(Switching t, int ttl) {
			super(t.nextState.get(), ttl);
			theStat = t.theStat;
			theClient = t.theClient;
			nextState = t.nextState;
			allTriggers = t.allTriggers;

		}

		@Override
		public boolean timedOut() {
			if (super.timedOut()) {
				if (allTriggers.isEmpty()) {
					return true;

				}
				theClient.addStat(theStat, new Switching(this, allTriggers.poll().getAsInt()));
				theClient.refreshStats();

			}
			return false;

		}
	}

	/**
	 * A back and forth changing variant of StatState where two different stats take turns.
	 */
	public static class Alternating extends StatState {
		private final StatName theStat;
		private final StatName altStat;
		private final Avatar theClient;
		private final IntSupplier theTicks;
		private final IntSupplier altTicks;
		private final int counter;

		/**
		 * Constructor for an alternating StatState
		 * @param thisStat The initial StatName
		 * @param thatStat The other StatName
		 * @param value Properties associated with the stat
		 * @param switchesCnt The amount of stat switches
		 * @param thisClient The user whom to apply stats on
		 * @param theseTicks The supplier of amount of ticks the initial stat lasts before switching
		 * @param thoseTicks The supplier of amount of ticks the other stat lasts before switching back
		 */
		public Alternating(StatName thisStat, StatName thatStat, String value, int switchesCnt, Avatar thisClient, IntSupplier theseTicks, IntSupplier thoseTicks) {
			super(value, theseTicks.getAsInt());
			theStat = thisStat;
			altStat = thatStat;
			theClient = thisClient;
			theTicks = theseTicks;
			altTicks = thoseTicks;
			counter = switchesCnt;

		}

		private Alternating(Alternating t) {
			super(t.data, t.altTicks.getAsInt());
			theStat = t.altStat;
			altStat = t.theStat;
			theClient = t.theClient;
			theTicks = t.altTicks;
			altTicks = t.theTicks;
			counter = t.counter - 1;

		}

		@Override
		public boolean timedOut() {
			if (super.timedOut()) {
				if (counter > 0) {
					theClient.addStat(altStat, new Alternating(this));

				}
				return true;

			}
			return false;

		}
	}
}
