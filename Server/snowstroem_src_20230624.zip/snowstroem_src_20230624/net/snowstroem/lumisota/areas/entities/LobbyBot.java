package net.snowstroem.lumisota.areas.entities;

import java.util.regex.Pattern;

import net.snowstroem.lumisota.Lumisota;
import net.snowstroem.lumisota.areas.Area;

/**
 * The drink dispenser of lobby areas
 *
 */
public class LobbyBot extends InteractiveBot {
	private static final byte DISPENSER_X = 8, BOT_Y = 1;
	private static final Pattern
	P_DRINK = Pattern.compile(".*(ka(h(a)?v|ff)|sump(pi|in)|k(u|a)a(k)?kao|kupp(i|onen)).*", Pattern.CASE_INSENSITIVE),
	P_THANKS = Pattern.compile("^kiito(s(ta)?|ks(et|ia))|tattis(ta)?.*", Pattern.CASE_INSENSITIVE);
	public static final String[]
			ON_MY_WAY = {"Tulossa!", "Hetkinen vain!", "Juomasi tulee tuossa tuokiossa!"},
			HERE_YOU_ARE = {"Tässä juomanne, olkaa hyvä.", "Valmista tuli!", "Nauti täysin siemauksin!", "Varovasti; juoma höyryää vielä!", "Kas tässä, ole hyvä."},
			NO_PROBLEM = {"Ole hyvä!", "Kiitos itsellesi!", "Eipä kestä.", "Ilo on minun puolellani!"},
			APOLOGY_ACCEPTED = {"Ei se mitään!", "Mitä nyt pienistä.", "Joskus sitä sattuu.", "Huoli pois, asia on unohdettu!"},
			ALREADY_DRINKING = {"Tyhjennäppä se muki kädessäsi ensin.", "Aiotko kaksin käsin juoda?", "Mutta sinulla on jo juotavaa!"},
			WAIT_A_MINUTE = {"Kysy kohta uudestaan!", "Odottaisitko hetkisen?", "Malta tovi!"},
			SELF_CHATTER = {};
	private LobbyBotTask lastTask;
	private Avatar drinkTarget;

	public LobbyBot(String displayName, String looks, String customData, Area area) {
		super(displayName, looks, customData, area);
		x = 11;
		y = 1;
		bdRot = hdRot = 4;
		resetIdle(true);
		refreshStats();
		lastTask = LobbyBotTask.NONE;

	}

	@Override
	public void reactTo(Avatar ac, String input) {
		if (ac.y == 3 && ac.x > 7) {
			if (P_THANKS.matcher(input).matches()) {
				venue.chat(this, false, null, NO_PROBLEM[Lumisota.RNG.nextInt(NO_PROBLEM.length)]);

			} else if (!isIdle()) {
				venue.chat(this, false, null, WAIT_A_MINUTE[Lumisota.RNG.nextInt(WAIT_A_MINUTE.length)]);

			} else if (P_DRINK.matcher(input).matches()) {
				if (ac.hasStat(StatName.CARRYD) || ac.hasStat(StatName.DRINK)) {
					venue.chat(this, false, null, ALREADY_DRINKING[Lumisota.RNG.nextInt(ALREADY_DRINKING.length)]);

				} else {
					stopIdle();
					drinkTarget = ac;
					venue.chat(this, false, null, ON_MY_WAY[Lumisota.RNG.nextInt(ON_MY_WAY.length)]);
					lastTask = LobbyBotTask.DRINK_INIT_DISPENSER;

				}
			}
		}
	}

	@Override
	void updateTask() {
		switch(lastTask) {
		case DRINK_INIT_DISPENSER: {
			venue.move(this, DISPENSER_X, BOT_Y);
			lastTask = LobbyBotTask.DRINK_GOTO_DISPENSER;
			break;

		} case DRINK_GOTO_DISPENSER: {
			if (!hasPath()) {
				hdRot = bdRot = 0;
				refreshStats();
				lastTask = LobbyBotTask.DRINK_GRAB_DISPENSER;
			}
			break;

		} case DRINK_GRAB_DISPENSER: {
			if (drinkTarget.y == 3 && drinkTarget.x > 7) {
				addStat(StatName.CARRYD, new StatState.Indefinite(""));
				lastTask = LobbyBotTask.DRINK_LOCATE_TARGET;

			} else {
				lastTask = LobbyBotTask.NONE;
			}
			break;

		} case DRINK_LOCATE_TARGET: {
			if (drinkTarget.y == 3 && drinkTarget.x > 7) {
				venue.move(this, drinkTarget.x, BOT_Y);
				lastTask = LobbyBotTask.DRINK_GOTO_TARGET;

			} else {
				removeStat(StatName.CARRYD);
				drinkTarget = null;
				lastTask = LobbyBotTask.NONE;
			}
			break;

		} case DRINK_GOTO_TARGET: {
			if (!hasPath()) {
				hdRot = bdRot = 4;
				refreshStats();
				lastTask = LobbyBotTask.DRINK_GIVE_TARGET;
			}
			break;

		} case DRINK_GIVE_TARGET: {
			if (drinkTarget.y == 3 && drinkTarget.x > 7) {
				venue.chat(this, false, null, HERE_YOU_ARE[Lumisota.RNG.nextInt(HERE_YOU_ARE.length)]);
				drinkTarget.addStat(StatName.CARRYD, new StatState.Alternating(StatName.CARRYD, StatName.DRINK, "", 15 + Lumisota.RNG.nextInt(11), drinkTarget, () -> 15, () -> 5));

			}
			removeStat(StatName.CARRYD);
			drinkTarget = null;
			lastTask = LobbyBotTask.NONE;
			break;

		} case WALK_TO: {
			if(!hasPath()) {
				lastTask = LobbyBotTask.NONE;
			}
			break;

		} default: {
			bdRot = hdRot = 4;
			resetIdle(true);
			refreshStats();
			break;
		}
		}
	}

	@Override
	void doIdleTask() {
		stopIdle();
		lastTask = LobbyBotTask.WALK_TO;
		venue.move(this, (byte) (DISPENSER_X + Lumisota.RNG.nextInt(7)), BOT_Y);

	}

	private enum LobbyBotTask {
		NONE,
		DRINK_INIT_DISPENSER,
		DRINK_GOTO_DISPENSER,
		DRINK_GRAB_DISPENSER,
		DRINK_LOCATE_TARGET,
		DRINK_GOTO_TARGET,
		DRINK_GIVE_TARGET,
		WALK_TO;

	}
}
