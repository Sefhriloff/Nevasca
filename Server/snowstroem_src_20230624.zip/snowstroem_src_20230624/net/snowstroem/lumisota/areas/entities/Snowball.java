package net.snowstroem.lumisota.areas.entities;

import net.snowstroem.lumisota.fuse.ListenerCall;
import net.snowstroem.lumisota.parsing.Geometry;

/**
 * Snowball entities fly inside a SnowfightArea and take hitpoints from an Avatar they land on if any.
 */
public final class Snowball {
	/**
	 * ID of this Snowball. Even though duplicates will not erase previous snowballs of same ID, an unique number is used.
	 */
	public final int id;

	/**
	 * Snowball origin X
	 */
	private final byte throwX;

	/**
	 * Snowball origin Y
	 */
	private final byte throwY;

	/**
	 * Snowball landing X
	 */
	public final byte targetX;

	/**
	 * Snowball landing Y
	 */
	public final byte targetY;

	/**
	 * The factor from which snowball velocity in X and Y axis along with lifetime and angle can be retrieved
	 */
	public final int speed;

	/**
	 * Constructs a snowball entity
	 * @param sbId Snowball id
	 * @param fromX Snowball thrower's X-coordinate
	 * @param fromY Snowball thrower's Y-coordinate
	 * @param toX Intended landing spot X-coordinate
	 * @param toY Intended landing spot Y-coordinate
	 * @param sbAngle The "angle" (rather highest point snowball reaches during flight), affects Snowball ttl.
	 */
	public Snowball(final int sbId, final byte fromX, final byte fromY, byte toX, byte toY, final byte sbAngle) {
		id = sbId;
		if (Geometry.distance(fromX, fromY, toX, toY) > sbAngle) { // Override snowball destination when target is further than throwing angle.
			final double rad = Geometry.getRad(fromX, fromY, toX, toY);
			toX = Geometry.coordByDirection(false, fromX, sbAngle, rad);
			toY = Geometry.coordByDirection(true, fromY, sbAngle, rad);

		}
		speed = sbAngle * 50;
		throwX = fromX;
		throwY = fromY;
		targetX = toX;
		targetY = toY;

	}

	public byte[] throwingMessage() {
		return new ListenerCall("SNOWBALL").append(id).ws()
				.append(throwX).ws().append(throwY).ws().append(0).ws() // XYZ, may use Z=1 to look like it originates from thrower's hands.
				.append(Float.toString((float) (targetX - throwX) / speed)).ws() // Directional velocities
				.append(Float.toString((float) (targetY - throwY) / speed)).ws()
				.append(speed / 50).ws().append(speed - 25).toBytes(); // Angle and lifetime in ms

	}
}
