package net.snowstroem.lumisota.areas.entities;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;

import net.snowstroem.lumisota.areas.Area;
import net.snowstroem.lumisota.areas.NodeData;
import net.snowstroem.lumisota.parsing.Geometry;

/**
 * Visually representable entity that can move around inside rooms and interact with each other and certain objects
 *
 */
public abstract class Avatar implements ActiveEntity {
	/**
	 * The Area this Avatar is located in
	 */
	protected final Area venue;

	/**
	 * Copy of username from User class, interned String
	 */
	public final String name;

	/**
	 * Avatar's looks code
	 */
	private final String figure;

	/**
	 * The description that can be seen by clicking on the avatar
	 */
	private final String description;

	/**
	 * Current X location
	 */
	public byte x;

	/**
	 * Current Y location
	 */
	public byte y;

	/**
	 * Current height position
	 */
	public byte z;

	/**
	 * Current heading of avatar's head
	 */
	public byte hdRot;

	/**
	 * Current heading of avatar's body
	 */
	public byte bdRot;

	/**
	 * True if walking is not prohibited
	 */
	public boolean canMove;

	/**
	 * Current status of in-area avatar
	 * Status consists of A.C. avatar's position, heading and acquired ClientStats
	 */
	private final StringBuilder status;

	/**
	 * ClientStat container for additional status data such as walking/running and drinking
	 */
	private final Map<StatName, StatState> m_stats;

	/**
	 * Avatar's pre-calculated path should a new destination have been issued
	 */
	private final Deque<NodeData> moveTiles;

	/**
	 * Temporary storage of last polled path node
	 */
	private NodeData tempNode;

	public Avatar(final String displayName, final String looks, final String customData,  final Area area) {
		name = displayName;
		figure = looks;
		description = customData;
		moveTiles = new ArrayDeque<>();
		m_stats = new EnumMap<>(StatName.class);
		status = new StringBuilder();
		venue = area;
		canMove = true;

	}

	public String usersEntry() {
		return name + ' ' + figure + ' ' + x + ' ' + y + ' ' + z + ' ' + description;

	}

	@Override
	public boolean checkStatusUpdates() {
		if (m_stats.values().removeIf(StatState::timedOut)) {
			if (hasPath()) { // Avatar is moving - look up next tile
				tempNode = moveTiles.pollFirst();
				final NodeData skip = moveTiles.peekFirst();
				if (skip != null && Math.abs(x - skip.x) <= 1 && Math.abs(y - skip.y) <= 1) { // Not about to progress two steps forward?
					byte skipOffset, avrOffset; // Search neighbouring tiles' (visually analogous to circles on % symbol) free-ness to prevent cutting corners
					if (skip.x > x) {
						skipOffset = -1;
						avrOffset = 1;

					} else {
						skipOffset = 1;
						avrOffset = -1;

					}
					if (venue.getNode(skip.x + skipOffset, skip.y).free() && venue.getNode(x + avrOffset, y).free()) {
						tempNode = moveTiles.pollFirst(); // skip verified, remove from stack

					}
				}
				if (tempNode.entityOnTile.isPresent()) { // On collision course; reroute
					final NodeData goal = getDestination();
					clearPath();
					tempNode = null;
					if (goal != null) {
						venue.move(this, goal.x, goal.y);

					}
				}
				if (tempNode != null) {
					hdRot = bdRot = Geometry.rotationBy(x, y, tempNode.x, tempNode.y);
					// Side effect from being added after checking for timed out items requires zero ttl on this status
					addStat(StatName.MV, new StatState(tempNode.x + "," + tempNode.y + "," + tempNode.z, 0));
					tempNode.entityOnTile = Optional.of(this); // Avatar is present on the next tile
					venue.getNode(x, y).entityOnTile = Optional.empty();

				}
			} else if (tempNode != null) { // Avatar is stopping, look for chair
				venue.getNode(x, y).objectOnTile.ifPresent(o -> {
					hdRot = bdRot = o.rotation;
					addStat(StatName.SIT, new StatState.Indefinite(""));

				});
				tempNode = null;
			}

			// All changes caught up: rewrite status with changes
			status.setLength(0);
			status.append(name).append(' ')
			.append(x).append(',').append(y).append(',').append(z).append(',')
			.append(hdRot).append(',').append(bdRot);

			if (m_stats.isEmpty()) {
				status.append('/');

			} else {
				for (Map.Entry<StatName, StatState> st : m_stats.entrySet()) {
					status.append('/').append(st.getKey().toString()).append(' ').append(st.getValue().data);

				}
			}
			if (tempNode != null) {
				x = tempNode.x;
				y = tempNode.y;
				z = tempNode.z;

			}
			return true;

		}

		return false;
	}

	@Override
	public CharSequence getStatus() {
		return status;

	}

	public boolean hasPath() {
		return !moveTiles.isEmpty();

	}

	public void clearPath() {
		moveTiles.clear();

	}

	public NodeData getDestination() {
		return moveTiles.peekLast();

	}

	public void setNewPath(final Deque<NodeData> collection) {
		clearPath();
		while (!collection.isEmpty()) moveTiles.addLast(collection.pollFirst());

		tempNode = moveTiles.pollFirst(); // Remove first entry

	}

	public void lookTo(final byte atX, final byte atY) {
		if (!hasPath() && !hasStat(StatName.SIT) && (x != atX || y != atY)) {
			byte rotation = Geometry.lookTo(Geometry.getRad(x, y, atX, atY));
			if (rotation != hdRot) {
				hdRot = rotation;
				rotation = (byte) Math.abs(bdRot - hdRot);
				if (rotation != 7 && rotation > 1) bdRot = hdRot;

			}

			refreshStats();
		}
	}
	public void angleHeadTo(final byte toX, final byte toY) {
		if (!hasPath()) { // Obtain rotation to turn towards
			final byte angle = Geometry.lookTo(Geometry.getRad(x, y, toX, toY));
			// Decide where head turns
			if (bdRot == angle) {
				hdRot = bdRot;

			} else if (bdRot < angle) {
				if (Math.abs(bdRot - angle) < 4) hdRot = (byte) (bdRot + 1);
				else hdRot = (byte) (bdRot - 1);

			} else if (Math.abs(bdRot - angle) < 4) {
				hdRot = (byte) (bdRot - 1);

			} else {
				hdRot = (byte) (bdRot + 1);
			}

			// Check the rotation boundaries
			if (hdRot < 0) hdRot = 7;
			else if (hdRot > 7) hdRot = 0;

			refreshStats();

		}
	}

	public void addStat(final StatName name, final StatState stat) {
		m_stats.put(name, stat);

	}

	public boolean hasStat(final StatName name) {
		return m_stats.containsKey(name);

	}

	public boolean removeStat(final StatName name) {
		return m_stats.remove(name) != null;

	}

	public void freeze() {
		canMove = false;
		clearPath();
		tempNode = null;

	}

	public void unfreeze() {
		canMove = true;

	}

	public void refreshStats() {
		addStat(StatName.STAND, new StatState(null, 0));

	}
}
