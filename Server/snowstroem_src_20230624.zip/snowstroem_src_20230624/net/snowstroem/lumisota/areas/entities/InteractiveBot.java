package net.snowstroem.lumisota.areas.entities;

import net.snowstroem.lumisota.Lumisota;
import net.snowstroem.lumisota.areas.Area;

/**
 * An avatar that is not directly controlled by clients
 *
 */
public abstract class InteractiveBot extends Avatar {
	private int idleTicks;

	public InteractiveBot(String displayName, String looks, String customData, Area area) {
		super(displayName, looks, customData, area);

	}

	public abstract void reactTo(Avatar ac, String input);

	/**
	 * Signals that the bot is no longer idle.
	 */
	protected void stopIdle() {
		idleTicks = -1;

	}

	/**
	 * Sets new idle period for this bot.
	 * @param disengage true if bot should enter idle state from busy state
	 */
	protected void resetIdle(final boolean disengage) {
		if (idleTicks <= 0 || disengage) {
			idleTicks = 10 + Lumisota.RNG.nextInt(50);

		}
	}

	public boolean isIdle() {
		return idleTicks >= 0;

	}

	@Override
	public boolean checkStatusUpdates() {
		if (idleTicks < 0) { // Busy
			updateTask();

		} else if (--idleTicks <= 0) { // Time for new task
			doIdleTask();

		}
		return super.checkStatusUpdates();

	}

	abstract void updateTask();
	abstract void doIdleTask();

}
