package net.snowstroem.lumisota.areas.entities;

/**
 * A static object (such as a table, chair or block of snow) inside an area.
 *
 */
public class AreaObject {
	/**
	 * The internal name of this AreaObject. Used for determining bitmaps to display.
	 */
	public final String sprite;

	/**
	 * The X coordinate of this AreaObject in the Area's map.
	 */
	public final byte x;

	/**
	 * The Y coordinate of this AreaObject in the Area's map.
	 */
	public final byte y;

	/**
	 * The rotation of an AreaObject.
	 * Used for determining bitmaps to display and sitting direction if interactive.
	 * Enables double diameter behavior (a 2-by-2-tile object) if set to 8.
	 */
	public final byte rotation;


	/**
	 * AreaObject constructor
	 * @param spriteCode AreaObject sprite
	 * @param xPos AreaObject x coordinate
	 * @param yPos AreaObject y coordinate
	 * @param rot AreaObject rotation, 8 to mark double-diameter object
	 */
	public AreaObject(final String spriteCode, final int xPos, final int yPos, final int rot) {
		sprite = spriteCode;
		x = (byte) xPos;
		y = (byte) yPos;
		rotation = (byte) rot;

	}
}