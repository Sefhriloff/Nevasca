package net.snowstroem.lumisota.areas.entities;

/**
 * An interactive entity of an area
 *
 */
public interface ActiveEntity {

	/**
	 * Looks for updates to entity's status
	 * @return true if there are updates made to status
	 */
	public boolean checkStatusUpdates();

	/**
	 * Outputs current status of this entity
	 * @return entity status
	 */
	public CharSequence getStatus();

}
