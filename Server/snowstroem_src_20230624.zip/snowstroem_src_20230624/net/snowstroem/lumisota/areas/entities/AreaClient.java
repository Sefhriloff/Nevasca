package net.snowstroem.lumisota.areas.entities;

import java.util.OptionalInt;

import net.snowstroem.lumisota.areas.Area;
import net.snowstroem.lumisota.fuse.Client;
import net.snowstroem.lumisota.users.Player;
import net.snowstroem.lumisota.users.UserRegistry;

/**
 * AreaClient (A.C.) is an entity representing a client connected to a cottage. (server)
 * Each AreaClient appears in an Area as an avatar that can walk across the Area and interact with other entities inside
 *
 */
public class AreaClient extends Avatar {

	/**
	 * Client object associated with this AreaClient for receiving in-area comms
	 */
	private final Client client;

	/**
	 * Snowfights only: True if this client is on red side
	 */
	public final boolean onRedTeam;

	/**
	 * Snowfights only: Remaining endurance against incoming snowballs. (0-10/14) One hit from snowball takes 2 points.
	 */
	public byte hitPoints = 1;

	/**
	 * Snowfights only: amount of carried snowballs (0-5/7)
	 */
	public byte snowballs = 0;

	/**
	 * true if this player cannot receive damage from snowballs
	 */
	public boolean postDeath;

	/**
	 * Snowfights only: Enemy knockouts caused in this round
	 */
	public short enemykills;

	/**
	 * Snowfights only: Teammate/self knockouts caused in this round
	 */
	public short friendlykills;

	/**
	 * Snowfights only: Times knocked out this round
	 */
	public short deaths;

	/**
	 * Snowfights only: The score in this round
	 */
	public short points;

	/**
	 * AreaClient constructor
	 * @param cl Client to be associated with this A.C.
	 */
	public AreaClient(final Client cl, final Area area, final boolean redTeam, final OptionalInt rank) {
		super(cl.identity.username, cl.identity.figure, rank.isPresent() ?  cl.identity.customData + "\t" + cl.identity.score + " " + rank.getAsInt() : cl.identity.customData, area);
		client = cl;
		onRedTeam = redTeam;
		enemykills = friendlykills = deaths = points = 0;

	}

	public AreaClient(final Client cl, final Area area, final OptionalInt rank) {
		this(cl, area, false, rank);

	}

	public boolean acquireSnowball() {
		unfreeze();
		addStat(StatName.CARRYSB, new StatState(Byte.toString(++snowballs), 1));
		return true;

	}

	public void sendMessage(final byte[] msg) {
		client.queueCall(msg);

	}

	public boolean hitBonus() {
		return client.identity.damageBonus;

	}

	public boolean ballBonus() {
		return client.identity.ballBonus;

	}

	public boolean hitptBonus() {
		return client.identity.hitptBonus;

	}

	public void transferTo(Area other, boolean redTeam) {
		UserRegistry.findRank(client.identity.score, r -> client.setVenue(other, true, redTeam, r));
		venue.leavingUser(name, true);

	}

	public void updateScores(final boolean nonDraw, final boolean redWins) {
		final Player u = client.identity;
		u.gamesPlayed++;
		if (nonDraw && redWins == onRedTeam) {
			u.gamesWon++;

		}
		u.score += points;
		UserRegistry.updateStats(u);

	}

	public String genStatus() {
	return Byte.toString(hitPoints) + ',' + (onRedTeam ? "red" : "blue") + ',' + postDeath + ',' + (hitPoints == 0);

	}
}
