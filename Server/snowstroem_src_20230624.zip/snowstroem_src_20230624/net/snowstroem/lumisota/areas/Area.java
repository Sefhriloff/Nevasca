package net.snowstroem.lumisota.areas;

import static net.snowstroem.lumisota.parsing.ContentParsers.toFuseListener;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import net.snowstroem.lumisota.Lumisota;
import net.snowstroem.lumisota.areas.entities.ActiveEntity;
import net.snowstroem.lumisota.areas.entities.AreaClient;
import net.snowstroem.lumisota.areas.entities.AreaObject;
import net.snowstroem.lumisota.areas.entities.Avatar;
import net.snowstroem.lumisota.areas.entities.InteractiveBot;
import net.snowstroem.lumisota.areas.entities.StatState;
import net.snowstroem.lumisota.areas.entities.StatName;
import net.snowstroem.lumisota.fuse.Client;
import net.snowstroem.lumisota.fuse.FuseServer;
import net.snowstroem.lumisota.fuse.ListenerCall;
import net.snowstroem.lumisota.parsing.ContentParsers;

/**
 * Area is an environment that enable players to interact with each other in real-time
 *
 */
public abstract class Area implements Runnable {
	private final static short
	STATUS_THRESHOLD = 10,
	PING_THRESHOLD = 30,
	FULL_HEARING_THRESHOLD = 10,
	PART_HEARING_THRESHOLD = 15;

	private final static ArrayDeque<NodeData> NO_PATH = new ArrayDeque<>(0);
	NodeData[] squares;

	/**
	 * The backing server of this Area
	 */
	final FuseServer host;

	final int mapNum;
	int mapMaxX;
	int mapMaxY;

	/**
	 * List of clients inside an Area
	 */
	final List<AreaClient> users;

	/**
	 * The scheduled task for status updates, primarily movement between tiles
	 */
	private ScheduledFuture<?> areaTask;

	private int ping = 0;

	private String statusMsg;

	/**
	 * Array index of this Area
	 */
	public final byte id;

	public Area(final FuseServer server, final byte idNum, final int map) {
		host = server;
		users = new ArrayList<>(30);
		id = idNum;
		mapNum = map;
		mapMaxX = Maps.mapXDiameter(map);
		mapMaxY = Maps.mapYDiameter(map);
		squares = Maps.prepMap(map);
	}

	protected abstract long getTick();

	public AreaClient enterUser(final Client client, final boolean altPos, final boolean redTeam, final OptionalInt rank) {
		if (users.isEmpty()) { // First inside, boot activity task
			areaTask = Lumisota.SCHEDULER.scheduleAtFixedRate(this, getTick(), getTick(), TimeUnit.MILLISECONDS);

		}
		client.queueCall(Maps.HEIGHTMAPS[mapNum]);
		client.queueCall(Maps.OBJMAPS[mapNum]);
		final AreaClient newUser = new AreaClient(client, this, redTeam, rank);
		positionClient(newUser, altPos);
		broadcast(new ListenerCall("USERS").append(newUser.usersEntry()));
		squares[newUser.y * mapMaxX + newUser.x].entityOnTile = Optional.of(newUser);
		synchronized(users) {
			users.add(newUser);
			client.queueCall(Stream.concat(users.stream(), getBots()).map(Avatar::usersEntry).collect(toFuseListener("USERS")));
			client.queueCall(Stream.concat(users.stream(), getBots()).map(Avatar::getStatus).collect(toFuseListener("STATUS")));
		}

		drawGameboard().sendTo(client);
		return newUser;
	}

	public void leavingUser(final String uname, final boolean transfer) {
		findByUsername(uname).ifPresent(a -> {
			synchronized(users) {
				if (transfer) {
					users.remove(a);
					broadcast(new ListenerCall("LOGOUT").append(a.name));

				} else {
					broadcast(new ListenerCall("LOGOUT").append(a.name));
					users.remove(a);
					removeFromGame(a);
				}
				squares[a.y * mapMaxX + a.x].entityOnTile = Optional.empty();
			}
		});
		if (users.isEmpty() && areaTask != null) { // Stop activity task as nobody is viewing it.
			if (this instanceof SnowfightArea) {
				host.closeArea(this.id);

			} else {
				areaTask.cancel(true);
			}
		}
	}

	public abstract void removeFromGame(final AreaClient ac);

	public Optional<AreaClient> findByUsername(final String name) {
		synchronized (users) {
			return users.stream().filter(a -> a.name.equals(name)).findAny();
		}
	}

	public Optional<Avatar> findByPosition(final byte x, final byte y) {
		synchronized (users) {
			return squares[y * mapMaxX + x].entityOnTile;
		}
	}

	public int getPlayerCount() {
		return users.size();
	}

	public final void broadcast(final byte[] msg) {
		synchronized(users) {
			for (AreaClient u : users) {
				u.sendMessage(msg);

			}
		}

		ping = 0;
	}

	public final void broadcast(final String msg) {
		broadcast(msg.getBytes(ContentParsers.CHARSET));
	}

	public final void broadcast(final ListenerCall msg) {
		broadcast(msg.toBytes());
	}

	public abstract void positionClient(final AreaClient ac, final boolean alternate);

	public abstract ListenerCall drawGameboard();
	public abstract void makeGameEvent(final AreaClient ac, final String data);
	public abstract void joinGameEvent(final AreaClient ac, final String data);
	public abstract void disposeGameEvent(final AreaClient ac, final String data);
	public abstract void beginGameEvent(AreaClient ac, String data);

	public void chat(final Avatar ac, final boolean shout, final String target, final String msg) {
		if (shout) {
			broadcast(new ListenerCall("SHOUT").append(ac.name).ws().append(msg));
			synchronized(users) {
				final byte saysX = ac.x, saysY = ac.y;
				for (AreaClient u : users) {
					if (u != ac) u.angleHeadTo(saysX, saysY);
				}
			}

			if (msg.equals("Sieg hail!") && !ac.hasStat(StatName.SIT)) { // A very vital feature
				ac.freeze();
				ac.addStat(StatName.THROWING, new StatState.Triggering("", 8, ac::unfreeze));
			}

		} else if (target == null) { // Say mode, limit complete messages to 10 squares and partially dotted up to 15
			final byte saysX = ac.x, saysY = ac.y;
			final byte[] chatMsg = new ListenerCall("CHAT").append(ac.name).ws().append(msg).toBytes();
			final ArrayList<AreaClient> partials = new ArrayList<>(users.size());
			synchronized(users) {
				for (AreaClient u : users) {
					final int distance = Math.max(Math.abs(saysX - u.x), Math.abs(saysY - u.y));
					if (distance <= FULL_HEARING_THRESHOLD) { // Within hearing range, see full message
						u.sendMessage(chatMsg);
						if (u != ac) u.angleHeadTo(saysX, saysY);

					} else if (distance <= PART_HEARING_THRESHOLD) { // Within hearing range, but unable to hear this well
						partials.add(u);
						u.angleHeadTo(saysX, saysY);
					}
				}
			}

			if (!partials.isEmpty()) { // Serve others the limited message
				// 012345   6789...
				// #CHAT[CR]username msg##
				for (int i = 6 + ac.name.length(); i < chatMsg.length - 2; i++) {
					if (chatMsg[i] != ' ' && Lumisota.RNG.nextFloat() < 0.333f) { // replace 1/3 of non-space chars
						chatMsg[i] = '.';
					}
				}

				for (AreaClient p : partials) {
					p.sendMessage(chatMsg);
				}
			}

			getBots().forEach(b -> b.reactTo(ac, msg)); // See if any bots are interested

		} else { // Whisper mode, only shared with each other
			final byte[] w = new ListenerCall("WHISPER").append(ac.name).ws().append(msg).toBytes();
			if (ac instanceof AreaClient) ((AreaClient) ac).sendMessage(w);
			findByUsername(target)
			.filter(a -> ac != a)
			.ifPresent(a -> a.sendMessage(w));
		}

		ac.addStat(StatName.TALK, new StatState("", msg.length() / 3 + 1));
		ac.refreshStats();

	}

	public void move(final Avatar avr, final byte x2, final byte y2) {
		if (avr.canMove && (avr.x != x2 || avr.y != y2) && squares[y2 * mapMaxX + x2] != avr.getDestination() && inBounds(x2, y2)) {
			Optional<AreaObject> obj = squares[y2 * mapMaxX + x2].objectOnTile;
			if (obj.isPresent()) {
				squares[y2 * mapMaxX + x2].objectOnTile = Optional.empty();

			}
			final Deque<NodeData> newPath = getPath(avr.x, avr.y, x2, y2);
			if (obj.isPresent()) {
				squares[y2 * mapMaxX + x2].objectOnTile = obj;

			}
			if (!newPath.isEmpty()) {
				avr.removeStat(StatName.SIT);
				avr.setNewPath(newPath);
				avr.refreshStats();

			}
		}
	}

	public void shutdown() {
		if (areaTask != null) areaTask.cancel(false);
		synchronized(users) {
			for (AreaClient a : users) a.sendMessage(new ListenerCall("LOGOUT").append(a.name).toBytes());
		}
	}

	protected abstract Stream<ActiveEntity> getUpdateables();
	protected abstract Stream<InteractiveBot> getBots();

	@Override
	public void run() {
		try {
			synchronized(users) {
				statusMsg = Stream.concat(getUpdateables(), users.stream())
						.filter(ActiveEntity::checkStatusUpdates)
						.map(ActiveEntity::getStatus)
						.collect(toFuseListener("STATUS"));
			}
			if (statusMsg.length() > STATUS_THRESHOLD || ++ping > PING_THRESHOLD) broadcast(statusMsg);
		} catch (Exception ex) {
			ex.printStackTrace();
			host.closeArea(id);
		}
	}

	public boolean nonUserBlocked(final byte x, final byte y) {
		synchronized (users) {
			return !squares[y * mapMaxX + x].entityOnTile.isPresent();
		}
	}

	public boolean inBounds(int x, int y) {
		return y < mapMaxY && x < mapMaxX && y >= 0 && x >= 0;
	}

	public NodeData getNode(int x, int y) {
		return squares[y * mapMaxX + x];
	}

	private ArrayDeque<NodeData> getPath(final int startX, final int startY, final int endX, final int endY) {
		final MetaNode[] meta = new MetaNode[mapMaxY * mapMaxX]; // Path search information
		final ArrayList<NodeData> open = new ArrayList<>(20); // Open list
		final ArrayList<NodeData> closed = new ArrayList<>(20); // Closed list
		int
		curX = startX,
		curY = startY,
		curZ = squares[curY * mapMaxX + curX].z,
		curG = 5, // This particular A* implementation uses a G factor of 5 to keep in balance with H.
		bestF,
		bestX = -1,
		bestY = -1;
		closed.add(squares[curY * mapMaxX + curX]); // Start set
		while (curX != endX || curY != endY) {
			bestF = Integer.MAX_VALUE; // Reset F result
			for (NodeData nd : neighbours(curX, curY)) { // 4-way connections to node currently picked
				if (nd != null && nd.free() && nd.z - curZ < 2 && !closed.contains(nd)) {
					MetaNode mn = meta[nd.y * mapMaxX + nd.x];
					if (mn == null) { // No meta yet, create open list member's info
						mn = meta[nd.y * mapMaxX + nd.x] = new MetaNode();
						mn.parentX = curX;
						mn.parentY = curY;
						mn.gVal = curG;
						int dx = Math.abs(nd.x - endX);
						int dy = Math.abs(nd.y - endY);
						mn.hVal = dx + dy + Math.min(dx, dy); // H = distances on axises plus shortest one of them
						open.add(nd);

					} else if (mn.gVal < curG + 5) { // Created by earlier node, see if it can serve this node instead
						mn.parentX = curX;
						mn.parentY = curY;
						mn.gVal = curG;

					}
				}
			}
			for (NodeData nd : open) { // Search lowest F open node
				if (meta[nd.y * mapMaxX + nd.x].fVal() < bestF) {
					bestX = nd.x;
					bestY = nd.y;
					bestF = meta[nd.y * mapMaxX + nd.x].fVal();

				}
			}
			if (bestF == Integer.MAX_VALUE) { // Open list exhausted
				return NO_PATH;

			}
			open.remove(squares[bestY * mapMaxX + bestX]); // Best match, scan neighbours of this node next
			curX = bestX;
			curY = bestY;
			curZ = squares[curY * mapMaxX + curX].z;
			curG += 5;
			closed.add(squares[curY * mapMaxX + curX]);

		}
		final ArrayDeque<NodeData> path = new ArrayDeque<>(closed.size());
		path.addFirst(squares[curY * mapMaxX + curX]); // Goal added
		while (curX != startX || curY != startY) { // Follow the path from goal to start
			MetaNode mn = meta[curY * mapMaxX + curX];
			path.addFirst(squares[(curY = mn.parentY) * mapMaxX + (curX = mn.parentX)]); // Sets next X/Y to look + adds node from this next X/Y

		}
		return path;

	}

	/**
	 * Gets the 4 neigbours of specified X/Y position.
	 * @param grid The area NodeData array
	 * @param x The X coordinate in middle of neighbours
	 * @param y The Y coordinate in middle of neighbours
	 * @return 4 or less neighbouring nodes with ones out of bounds replaced with null
	 */
	private NodeData[] neighbours(int x, int y) {
		return new NodeData[] {
				x == 0 ? null : squares[y * mapMaxX + (x - 1)],
				y == 0 ? null : squares[(y - 1) * mapMaxX + x],
				x + 1 == mapMaxX ? null : squares[y * mapMaxX + (x + 1)],
				y + 1 == mapMaxY ? null : squares[(y + 1) * mapMaxX + x]
		};
	}

	/**
	 * Path search specific data to accompany regular {@code NodeData}
	 * @author Asc
	 * @see NodeData
	 */
	private static class MetaNode {
		/**
		 * The X coordinate of node that last inherited this node
		 */
		private int parentX;

		/**
		 * The Y coordinate of node that last inherited this node
		 */
		private int parentY;

		/**
		 * The 'G' value, cost to move into this node from parent
		 */
		private int gVal;

		/**
		 * The 'H' value, heuristic estimate of additional expenses of using this node
		 */
		private int hVal;

		/**
		 * Gets the 'F' value, total approximated cost of using this tile in path
		 * @return G+H
		 */
		private int fVal() {
			return gVal + hVal;
		}
	}
}
