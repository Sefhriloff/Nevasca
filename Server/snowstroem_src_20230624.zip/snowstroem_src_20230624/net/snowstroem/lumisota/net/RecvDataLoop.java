package net.snowstroem.lumisota.net;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import net.snowstroem.lumisota.fuse.Client;

public class RecvDataLoop implements CompletionHandler<Integer, Client> {
	private final Consumer<ByteBuffer> finisher;
	private final ByteBuffer input;
	private final AsynchronousSocketChannel socket;

	public RecvDataLoop(final AsynchronousSocketChannel asc, final ByteBuffer b, final Consumer<ByteBuffer> f) {
		socket = asc;
		input = b;
		finisher = f;

	}

	public void init(int limit, Client cl, long sec) {
		socket.read(input.rewind().limit(limit), sec, TimeUnit.SECONDS, cl, this);

	}

	@Override
	public void completed(Integer result, Client c) {
		if (result < 1 || !socket.isOpen()) {
			c.host.removeClient(c);

		} else if (input.hasRemaining()) {
			socket.read(input, 10L, TimeUnit.SECONDS, null, this);

		} else {
			finisher.accept(input);
		}
	}

	@Override
	public void failed(Throwable exc, Client c) {
		System.out.println("Terminating Client on ".concat(c.getIp()).concat(" by ").concat(exc.toString()));
		c.host.removeClient(c);

	}
}
