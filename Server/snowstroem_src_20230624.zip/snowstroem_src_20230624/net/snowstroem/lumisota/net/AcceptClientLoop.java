package net.snowstroem.lumisota.net;

import static java.nio.channels.AsynchronousChannelGroup.withCachedThreadPool;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.function.Consumer;

import net.snowstroem.lumisota.Lumisota;

public class AcceptClientLoop implements CompletionHandler<AsynchronousSocketChannel, Void> {
	private final AsynchronousServerSocketChannel server;
	private final Consumer<AsynchronousSocketChannel> newCon;

	public AcceptClientLoop(final int port, final Consumer<AsynchronousSocketChannel> ci) throws IOException {
		newCon = ci;
		server = AsynchronousServerSocketChannel
				.open(withCachedThreadPool(Lumisota.SCHEDULER, Lumisota.SCHEDULER_CORES))
				.setOption(StandardSocketOptions.SO_REUSEADDR, true)
				.bind(new InetSocketAddress(port));

	}

	public void init() {
		server.accept(null, this);

	}

	public void kill() {
		try {
			server.close();

		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	public int getPort() {
		try {
			return ((InetSocketAddress) server.getLocalAddress()).getPort();

		} catch (IOException e) {
			e.printStackTrace();
			return 0;

		}
	}

	@SuppressWarnings("resource")
	@Override
	public void completed(AsynchronousSocketChannel ch, Void nil) {
		server.accept(null, this); // Start looking for new accepts
		try {
			// Not a resource leak: Channel is not supposed to be closed at this point
			ch.setOption(StandardSocketOptions.TCP_NODELAY, true);

		} catch (IOException e) {
			// ignore

		}
		newCon.accept(ch);

	}

	@Override
	public void failed(Throwable exc, Void nil) {
		// Ignore unacceptable sockets
	}
}
