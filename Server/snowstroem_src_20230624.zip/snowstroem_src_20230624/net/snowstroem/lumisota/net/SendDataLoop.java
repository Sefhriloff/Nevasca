package net.snowstroem.lumisota.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

public class SendDataLoop implements CompletionHandler<Integer, ByteBuffer> {
	private final Queue<ByteBuffer> msgQueue;
	private boolean writing = false;
	private final AsynchronousSocketChannel socket;

	public SendDataLoop(final AsynchronousSocketChannel asc) {
		socket = asc;
		msgQueue = new ArrayDeque<>();
	}

	private void writeFromQueue() {
		ByteBuffer buffer;
		synchronized (msgQueue) {
			writing = (buffer = msgQueue.poll()) != null;

		}
		if (writing) {
			socket.write(buffer, 50L, TimeUnit.SECONDS, buffer, this);

		}
	}

	public void send(final ByteBuffer buf) {
		if (buf.hasRemaining()) {
			boolean initWrite = false;
			synchronized(msgQueue) {
				msgQueue.add(buf);
				if (!writing) {
					writing = initWrite = true;

				}
			}
			if (initWrite) {
				writeFromQueue();

			}
		}
	}

	public String getIp() {
		try {
			return ((InetSocketAddress) socket.getRemoteAddress()).getAddress().getHostAddress();

		} catch (IOException e) {
			return "0.0.0.0";

		}
	}

	public boolean up() {
		return socket.isOpen();

	}

	/**
	 * Closes the channel
	 */
	public void kill() {
		try {
			socket.close();

		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	@Override
	public void completed(Integer result, ByteBuffer buffer) {
		if (buffer.hasRemaining()) {
			socket.write(buffer, 50L, TimeUnit.SECONDS, buffer, this);
		} else { // Look for more pending writes
			writeFromQueue();
		}
	}

	@Override
	public void failed(Throwable exc, ByteBuffer attachment) {
		// Ignored
	}
}
