package net.snowstroem.lumisota.parsing;

/**
 * Provides static functions that work with rotation value bytes (0-7) and coordinate values
 *
 */
public final class Geometry {
	private final static double ROTATION_SLICE = Math.PI / 4.0; //0.7853981633974483

	private Geometry() {}

	/**
	 * Gets a direction to turn towards by angle
	 *
	 * @param rad Direction towards target in radians
	 * @return A rotation value between 0 and 7
	 */
	public static byte lookTo(final double rad) {
		final long mathRotation = Math.round(rad / ROTATION_SLICE);
		return (byte) (mathRotation + (mathRotation < -2L ? 10 : 2));

	}

	/**
	 * Gets a direction (angle) by two sets of coordinates
	 *
	 * @param x X coordinate of User to rotate
	 * @param x Y coordinate of User to rotate
	 * @param toX Target's X coordinate
	 * @param toY Target's Y coordinate
	 * @return Angle towards target in radians
	 */
	public static double getRad(final byte x, final byte y, final byte toX, final byte toY) {
		return Math.atan2(toY - y, toX - x);

	}

	/**
	 * Calculates an X or Y coordinate from angle and distance
	 *
	 * @param y True if Y coordinate, false if X
	 * @param pt Starting coordinate
	 * @param distance How far the end coordinate is from Starting coordinate "pt"
	 * @param rad Angle towards end coordinate in radians
	 * @return A coordinate value
	 */
	public static byte coordByDirection(final boolean y, final byte pt, final byte distance, final double rad) {
		return (byte) Math.round(pt + distance * (y ? Math.sin(rad) : Math.cos(rad)));

	}

	/**
	 * Calculates a direction to turn a walking User towards
	 *
	 * @param x The User's current X coordinate
	 * @param y The User's current Y coordinate
	 * @param x2 The User's next X coordinate
	 * @param y2 The User's next Y coordinate
	 * @return A rotation value between 0 and 7
	 */
	public static byte rotationBy(byte x, byte y, byte x2, byte y2) {
		if (x > x2) {
			if (y == y2) return 6;
			if (y < y2) return 5;
			return 7;

		} if (x < x2) {
			if (y == y2) return 2;
			if (y < y2) return 3;
			return 1;

		}
		// x == x2
		if (y < y2) return 4;
		return 0;

	}

	/**
	 * Calculates distance between two sets of coordinates
	 *
	 * @param x1 The X coordinate of first location
	 * @param y1 The Y coordinate of first location
	 * @param x2 The X coordinate of second location
	 * @param y2 The Y coordinate of second location
	 * @return Distance between two points as amount of tiles
	 */
	public static double distance(byte x1, byte y1, byte x2, byte y2) {
		return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));

	}
}
