package net.snowstroem.lumisota.parsing;

import static java.util.Arrays.stream;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toMap;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.StringJoiner;
import java.util.stream.Collector;
import java.util.stream.Stream;

/**
 * Conversions for the data from some inputs
 *
 */
public final class ContentParsers {
	public static final Charset CHARSET = Charset.isSupported("cp1252") ? Charset.forName("cp1252") : StandardCharsets.ISO_8859_1;
	public static final CharsetEncoder CHRS_ENC = ContentParsers.CHARSET.newEncoder()
			.onMalformedInput(CodingErrorAction.REPLACE)
			.onUnmappableCharacter(CodingErrorAction.REPLACE);
	private ContentParsers() {}

	public static ByteBuffer chrsToBuffer(final CharSequence cs) {
			try {
				return CHRS_ENC.encode(CharBuffer.wrap(cs));
			} catch (CharacterCodingException e) {
				e.printStackTrace();

			}
			return ByteBuffer.allocate(0);
	}

	public static Collector<CharSequence, ?, String> toFuseListener(final String packetHead) {
		return joining("\r", "#".concat(packetHead).concat("\r"), "##");

	}

	private static Map<String, String> mapStrings(final Stream<String> input) {
		return input
				.map(l -> l.split("=", 2))
				.filter(kv -> kv.length == 2)
				.collect(toMap(kv -> kv[0].trim(), kv -> kv[1].trim(), (o, n) -> o));

	}

	public static String[] getParamPair(final String input) {
		return input.split(" ", 2);

	}

	public static Map<String, String> kvToMap(final String kvString) {
		return mapStrings(stream(kvString.split("\r")));

	}

	public static Map<String, String> kvFileToMap(final Path file) {
		try {
			return mapStrings(Files.lines(file));

		} catch (IOException e) {
			e.printStackTrace();
			return Map.of();

		}
	}

	public static String xtras(final boolean hanska, final boolean pallot, final boolean takki) {
		final StringJoiner x = new StringJoiner(" ");
		if (hanska) {
			x.add("hiteffect");

		}
		if (pallot) {
			x.add("balls");

		}
		if (takki) {
			x.add("energy");

		}
		return x.toString();

	}
}
