package net.snowstroem.lumisota.users;

import static org.mindrot.jbcrypt.BCrypt.checkpw;
import static org.mindrot.jbcrypt.BCrypt.hashpw;
import static org.mindrot.jbcrypt.BCrypt.gensalt;

import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.Consumer;

import net.snowstroem.lumisota.Lumisota;
import net.snowstroem.lumisota.fuse.Client;
import net.snowstroem.lumisota.fuse.FuseFilter;
import net.snowstroem.lumisota.fuse.FuseServer;
import net.snowstroem.lumisota.fuse.FuseServerManager;
import net.snowstroem.lumisota.fuse.ListenerCall;
import net.snowstroem.lumisota.parsing.ContentParsers;
import net.snowstroem.lumisota.sql.Queries;

/**
 * UserRegistry manages database retrieval and saving of user accounts and their information
 *
 */
public final class UserRegistry {
	private final static byte[] USER_NOT_FOUND = {'#','N','O','S', 'U', 'C', 'H','U','S','E','R','#','#'};
	private final static DateTimeFormatter ACTIVITY_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
	private UserRegistry() {}

	public static void authenticate(final String name, final String pass, final Consumer<Optional<Player>> task) {
		Queries.prepareAndRetrieve("SELECT * FROM ACCOUNTS WHERE HANDLE ILIKE ?",
				ps -> ps.setString(1, name),
				rs -> {
					if (checkpw(pass, rs.getString("PW")) && FuseServerManager.locateClient(rs.getInt("ID")) == "") { // Assign Users their info
						Player u = new Player(rs.getInt("ID"), rs.getString("HANDLE"));
						u.fillLoginInfo(rs);
						return Optional.of(u);

					}
					return Optional.empty();
				}, task);
	}

	public static void findUser(final Client cl, final String name) {
		Queries.prepareAndRetrieve("SELECT ID, HANDLE, FIGURE, CUSTOMDATA, ACCOUNTS.POINTS, PLAYS, WINS, LASTACTIVE, HITBONUS, BALLBONUS, HITPTBONUS, rnk.r " +
				"FROM ACCOUNTS " +
				"INNER JOIN (SELECT POINTS, ROW_NUMBER() OVER (ORDER BY POINTS DESC) AS r FROM ACCOUNTS GROUP BY POINTS) rnk " +
				"ON ACCOUNTS.POINTS = rnk.POINTS " +
				"WHERE HANDLE ILIKE ?",
				ps -> ps.setString(1, name),
				rs -> {
					final int totalPoints = rs.getInt(5), totalGames = rs.getInt(6);
					return Optional.of(new ListenerCall("MEMBERINFO")
							.append(rs.getString(2)).cr() // Name
							.append(rs.getString(4)).cr() // Personal message
							.append(ACTIVITY_FORMATTER.format(rs.getTimestamp(8).toLocalDateTime())).cr() // Last time active
							.append(totalPoints).ws() // Points
							.append(rs.getInt(12)).ws() // Overall ranking
							.append(totalGames > 0 ? totalPoints / totalGames : 0).ws() // Point average
							.append(rs.getInt(7)).ws() // Games won
							.append(0).ws() // unused word
							.append(totalGames).cr() // Games played
							.append(FuseServerManager.locateClient(rs.getInt(1))).cr() // Location: ENTERPRISESERVER, cottage name or blank for offline
							.append(rs.getString(3)).cr() // Figure
							.append(ContentParsers.xtras(rs.getBoolean(9), rs.getBoolean(10), rs.getBoolean(11)))
							.toBytes());

				}, o -> cl.queueCall(o.orElse(USER_NOT_FOUND)));
	}

	public static void findRank(final int pts, final Consumer<OptionalInt> rt) {
		Queries.prepareAndGetInt("SELECT rnk.r " +
				"FROM ACCOUNTS " +
				"INNER JOIN (SELECT POINTS, ROW_NUMBER() OVER (ORDER BY POINTS DESC) AS r FROM ACCOUNTS GROUP BY POINTS) rnk " +
				"ON ACCOUNTS.POINTS = rnk.POINTS " +
				"WHERE ACCOUNTS.POINTS = ? " +
				"LIMIT 1",
				ps -> ps.setInt(1, pts),
				rs -> rs.getInt(1),
				rt);

	}

	public static void registerUser(final Client cl, final Map<String, String> data, final Runnable onFailure) {
		final String ip = cl.getIp();
		String v = FuseFilter.filterInput(data.get("name"), true);
		if (v.length() < 2 || v.startsWith("lumirobo") || !data.containsKey("password") || data.get("password").length() < 1) {
			onFailure.run();

		}
		Queries.prepareAndIfExistsOrElse("SELECT * FROM ACCOUNTS WHERE HANDLE ILIKE ?",
				ps -> ps.setString(1, v),
				onFailure,
				() -> Queries.prepareAndEvaluateOrElse("SELECT COUNT(ID) FROM ACCOUNTS WHERE REGIP=?",
						ps -> ps.setString(1, ip),
						rs -> rs.getInt(1) >= 2,
						onFailure,
						() -> Queries.prepareAndExecute("INSERT INTO ACCOUNTS " +
								"(HANDLE, PW, FIGURE, CUSTOMDATA, AGE, EMAIL, PHONE, HOMEADDRESS, ZIPCODE, POSTLOCATION, FIRSTNAME, LASTNAME, REGIP) " +
								"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
								ps -> {
									ps.setString(1, v); // handle column set
									ps.setString(2, hashpw(data.get("password"), gensalt(0xa, Lumisota.RNG)));
									ps.setString(3, FuseFilter.filterFigure(data.get("figure")));
									ps.setString(4, FuseFilter.filterInput(data.get("customData"), false));
									String temp = data.get("age");
									ps.setShort(5, temp != null && v.length() <= 3 && temp.codePoints().allMatch(d -> d >= '0' && d <= '9')
											? Short.parseShort(temp) : 0);
									ps.setString(6, FuseFilter.filterInput(data.get("email"), false));
									temp =  FuseFilter.filterInput(data.get("phoneNumber"), false);
									ps.setString(7, temp.length() > 15 ? temp.substring(0, 15) : v);
									ps.setString(8, FuseFilter.filterInput(data.get("address"), false));
									ps.setString(9, FuseFilter.filterInput(data.get("zipcode"), false));
									ps.setString(10, FuseFilter.filterInput(data.get("postLocation"), false));
									ps.setString(11, FuseFilter.filterInput(data.get("firstName"), false));
									ps.setString(12, FuseFilter.filterInput(data.get("lastName"), false));
									ps.setString(13, ip);

								})));
	}

	public static void updateUser(final Map<String, String> data, final int usrId) {
		if (usrId > 0 && data.containsKey("password") && data.get("password").length() >= 1) {
			Queries.prepareAndExecute(
					"UPDATE ACCOUNTS SET PW=?, FIGURE=?, CUSTOMDATA=?, AGE=?, EMAIL=?, PHONE=?, HOMEADDRESS=?, ZIPCODE=?, POSTLOCATION=?, FIRSTNAME=?, LASTNAME=? WHERE ID=?",
					ps -> {
						ps.setString(1, hashpw(data.get("password"), gensalt(0xa, Lumisota.RNG))); // pw column set
						ps.setString(2, FuseFilter.filterFigure(data.get("figure"))); // figure column set
						ps.setString(3, FuseFilter.filterInput(data.get("customData"), false)); // customdata column set
						// Personal details, client will receive these later in USEROBJECT
						String v = data.get("age");
						ps.setShort(4, v != null && v.length() <= 3 && v.codePoints().allMatch(d -> d >= '0' && d <= '9')
								? Short.parseShort(v) : 0);
						ps.setString(5, FuseFilter.filterInput(data.get("email"), false));
						v = FuseFilter.filterInput(data.get("phoneNumber"), false);
						ps.setString(6, v.length() >= 15 ? v.substring(0, 15) : v);
						ps.setString(7, FuseFilter.filterInput(data.get("address"), false));
						ps.setString(8, FuseFilter.filterInput(data.get("zipcode"), false));
						ps.setString(9, FuseFilter.filterInput(data.get("postLocation"), false));
						ps.setString(10, FuseFilter.filterInput(data.get("firstName"), false));
						ps.setString(11, FuseFilter.filterInput(data.get("lastName"), false));
						ps.setInt(12, usrId);

					});
		}
	}

	public static void updateStats(final Player usr) {
		Queries.prepareAndExecute(
				"UPDATE ACCOUNTS SET POINTS=?, PLAYS=?, WINS=?, LASTACTIVE = NOW(0) WHERE ID=?",
				usr::fillStatsUpdate

				);
	}

	public static void writeAccessEntry(final int uId, final String ip) {
		Queries.prepareAndExecute("INSERT INTO ACCESS (IP, ACCOUNTID) VALUES (?, ?)",
				ps -> {
					ps.setString(1, ip);
					ps.setInt(2, uId);

				});
	}

	public static void tryDelete(final String handle) {
		FuseServerManager.servers(false)
		.flatMap(FuseServer::getAuths)
		.filter(c -> handle.equalsIgnoreCase(c.identity.username))
		.findAny().ifPresent(c -> c.host.removeClient(c));
		Queries.prepareAndExecute(
				"DELETE FROM ACCOUNTS WHERE HANDLE ILIKE ?",
				ps -> ps.setString(1, handle)

				);
	}

	public static void setXtras(final String handle, final boolean hitX, final boolean ballX, final boolean hpX) {
		FuseServerManager.servers(false)
		.flatMap(FuseServer::getAuths)
		.map(a -> a.identity)
		.filter(p -> handle.equalsIgnoreCase(p.username))
		.findAny().ifPresent(p -> {
			p.damageBonus = hitX;
			p.ballBonus = ballX;
			p.hitptBonus = hpX;

		});
		Queries.prepareAndExecute(
				"UPDATE ACCOUNTS SET HITBONUS=?, BALLBONUS=?, HITPTBONUS=? WHERE HANDLE ILIKE ?",
				ps -> {
					ps.setBoolean(1, hitX);
					ps.setBoolean(2, ballX);
					ps.setBoolean(3, hpX);
					ps.setString(4, handle);

				});
	}
}
