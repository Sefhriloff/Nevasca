package net.snowstroem.lumisota.users;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import net.snowstroem.lumisota.fuse.ListenerCall;

/**
 * Container of player identity and statistics
 * 
 */
public class Player {
	/**
	 * Unique ID number for this User. Not known by clients.
	 */
	public final int id;
	/**
	 * Unique handle for this User. Cannot be changed by clients. Interned on User initialization
	 */
	public final String username;

	/**
	 * First name of this User.
	 */
	public String firstName;

	/**
	 * Surname of this User.
	 */
	public String lastName;

	/**
	 * Email of this user. Originally probably used for spam and password reset.
	 */
	public String email;

	/**
	 * The figure string. Format example: 1,2,3. Digits only.
	 */
	public String figure;

	/**
	 * Home address of this User.
	 */
	public String address;

	/**
	 * Age reported by User. Allows numbers between 1 and 130.
	 */
	public short age;

	/**
	 * Postal code of User's home area
	 */
	public String zipcode;

	/**
	 * Postal office location of User's home area.
	 */
	public String postLocation;

	/**
	 * Mobile phone number of this User.
	 */
	public String phoneNumber;

	/**
	 * User custom data A.K.A motto.
	 */
	public String customData;

	/**
	 * True when player deals double damage in-game
	 */
	public boolean damageBonus;

	/**
	 * True when player can carry two more snowballs in-game
	 */
	public boolean ballBonus;

	/**
	 * True when player can withstand four points more damage in-game
	 */
	public boolean hitptBonus;

	/**
	 * Total personal score of this User
	 */
	public int score;

	/**
	 * Count of games played by this User
	 */
	public int gamesPlayed;

	/**
	 * Count of games in which this User joined the winning team
	 */
	public int gamesWon;

	/**
	 * Constructor for identifying the user
	 * @param i 
	 * @param handle the intended username to use
	 */
	Player(final int i, final String handle) {
		id = i;
		username = handle.intern();
	}

	public byte[] userObject() {
		return new ListenerCall("USEROBJECT")
				.append("name=").append(username).cr()
				.append("email=").append(email).cr()
				.append("figure=").append(figure).cr()
				.append("address=").append(address).cr()
				.append("age=").append(age).cr()
				.append("zipcode=").append(zipcode).cr()
				.append("firstName=").append(firstName).cr()
				.append("postLocation=").append(postLocation).cr()
				.append("lastName=").append(lastName).cr()
				.append("phoneNumber=").append(phoneNumber).cr()
				.append("customData=").append(customData)
				.toBytes();

	}



	/* UserRegistry helpers */

	void fillLoginInfo(final ResultSet rs) throws SQLException {
		figure = rs.getString("FIGURE");
		customData = rs.getString("CUSTOMDATA");
		score = rs.getInt("POINTS");
		gamesPlayed = rs.getInt("PLAYS");
		gamesWon = rs.getInt("WINS");
		age = rs.getShort("AGE");
		email = rs.getString("EMAIL");
		phoneNumber = rs.getString("PHONE");
		address = rs.getString("HOMEADDRESS");
		zipcode = rs.getString("ZIPCODE");
		postLocation = rs.getString("POSTLOCATION");
		firstName = rs.getString("FIRSTNAME");
		lastName = rs.getString("LASTNAME");
		damageBonus = rs.getBoolean("HITBONUS");
		ballBonus = rs.getBoolean("BALLBONUS");
		hitptBonus = rs.getBoolean("HITPTBONUS");

	}

	void fillStatsUpdate(final PreparedStatement ps) throws SQLException {
		ps.setInt(1, score);
		ps.setInt(2, gamesPlayed);
		ps.setInt(3, gamesWon);
		ps.setInt(4, id);

	}
}
