package net.snowstroem.lumisota.sql;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.Map;
import java.util.Queue;
import java.util.function.Consumer;
import java.util.function.Function;

import javax.sql.DataSource;

import org.h2.jdbcx.JdbcDataSource;

import net.snowstroem.lumisota.Lumisota;
import net.snowstroem.lumisota.LumisotaConfig;
import net.snowstroem.lumisota.parsing.ContentParsers;

/**
 * Database connection manager
 *
 */
public final class Database {
	private final static int MAX_CONNECTIONS;
	private final static DataSource SRC;
	private static int c_cnt = 0;
	static {
		Map<String, String> s_props = ContentParsers.kvFileToMap(LumisotaConfig.DB_CONF_P);
		JdbcDataSource ds = new JdbcDataSource();
		ds.setUrl(s_props.get("jdbcUrl"));
		ds.setUser(s_props.get("dbuser"));
		ds.setPassword(s_props.get("dbpass"));
		SRC = ds;
		MAX_CONNECTIONS = Integer.parseInt(s_props.getOrDefault("connectionLimit", "10"));

	}

	private final static Queue<Connection> CONNS = new ArrayDeque<>(MAX_CONNECTIONS);
	private final static Queue<Runnable> UNDONE_TASKS = new ArrayDeque<>();

	private Database(){}

	public static void useConnection(Consumer<Connection> connTask) {
		referencePool(c -> {
				connTask.accept(c);
				releaseConnection(c);

			}, () -> useConnection(connTask));
	}

	public static <T> void doRetrieval(Function<Connection, T> connTask, Consumer<T> resultTask) {
		referencePool(c -> {
				final T r = connTask.apply(c);
				releaseConnection(c);
				resultTask.accept(r);

		}, () -> doRetrieval(connTask, resultTask));
	}

	public static void doIfOrElse(SqlBoolean sb, Runnable yes, Runnable no) {
		referencePool(c -> {
			final boolean b = sb.evaluate(c);
			releaseConnection(c);
			(b ? yes : no).run();

		}, () -> doIfOrElse(sb, yes, no));
	}

	@SuppressWarnings("resource")
	private static void referencePool(Consumer<Connection> connTask, Runnable doLater) {
		Connection conn;
		do {
			synchronized(CONNS) {
				conn = CONNS.poll();

			}
			if (conn == null) {
				break;

			}
			try {
				if (conn.isValid(2)) {
					connTask.accept(conn);
					return;

				}
				c_cnt--;
				conn.close();

			} catch (SQLException e) {
				System.err.println("DBManager: cannot reuse connection!");
				e.printStackTrace();
				releaseConnection(conn);
				continue;

			}
		} while (CONNS.size() > 0);
		if (MAX_CONNECTIONS == 0 || c_cnt < MAX_CONNECTIONS) { // Room for a new connection?
			try {
				// Not a resource leak: Connection is stored for taking later queries
				conn = SRC.getConnection();
				c_cnt++;
				connTask.accept(conn);
				return;

			} catch (SQLException e) {
				System.err.println("DBManager: cannot create new connection!");
				e.printStackTrace();
				releaseConnection(conn);

			}
		}

		synchronized(UNDONE_TASKS) { // Execute when free connection is available
			UNDONE_TASKS.add(doLater);
		}
	}

	/**
	 * Returns a java.sql.Connection to the pool, so it can be used in other requests - or skips pooling and proceeds to next task with given Connection.
	 * 
	 * @param conn The java.sql.Connection to return to the pool.
	 */
	private static void releaseConnection(Connection conn) {
		if (conn != null) {
			synchronized (CONNS) {
				CONNS.add(conn);

			}
			final Runnable waitingTask;
			synchronized (UNDONE_TASKS) {
				waitingTask = UNDONE_TASKS.poll();

			}
			if (waitingTask != null) {
				Lumisota.SCHEDULER.execute(waitingTask);

			}
		}
	}
}
