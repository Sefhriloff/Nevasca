package net.snowstroem.lumisota.sql;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResultParsing<T> {
T parse(ResultSet rs) throws SQLException;
}
