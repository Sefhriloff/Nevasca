package net.snowstroem.lumisota.sql;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface StatementPreparement {
	void prep(PreparedStatement s) throws SQLException;
	default StatementPreparement andAlso(StatementPreparement next) {
		return (PreparedStatement s) -> {prep(s); next.prep(s);};
	}
}
