package net.snowstroem.lumisota.sql;

import java.sql.Connection;

interface SqlBoolean {
	public boolean evaluate(Connection c);
}
