package net.snowstroem.lumisota.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.Consumer;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public final class Queries {
	private Queries() {}

	public static void execute(final String query) {
		Database.useConnection(c -> {
			try (Statement s = c.createStatement()) {
				s.execute(query);

			} catch (SQLException e) {
				e.printStackTrace();

			}
		});
	}

	public static void prepareAndExecute(final String query, final StatementPreparement prepping) {
		Database.useConnection(c -> {
			try (PreparedStatement ps = c.prepareStatement(query)) {
				prepping.prep(ps);
				ps.execute();

			} catch (SQLException e) {
				e.printStackTrace();

			}
		});
	}

	public static void prepareAndIfExistsOrElse(final String query, final StatementPreparement prepping, final Runnable exists, final Runnable absent) {
		Database.doIfOrElse(c -> {
			try (PreparedStatement ps = c.prepareStatement(query)) {
				prepping.prep(ps);
				try (ResultSet rs = ps.executeQuery()) {
					return rs.next();

				}
			} catch (SQLException e) {
				e.printStackTrace();

			}
			return false;

		}, exists, absent);
	}

	public static void prepareAndEvaluateOrElse(final String query, final StatementPreparement prepping, final ResultEvaluation evaling, final Runnable exists, final Runnable absent) {
		Database.doIfOrElse(c -> {
			try (PreparedStatement ps = c.prepareStatement(query)) {
				prepping.prep(ps);
				try (ResultSet rs = ps.executeQuery()) {
					return rs.next() && evaling.evaluate(rs);

				}
			} catch (SQLException e) {
				e.printStackTrace();

			}
			return false;

		}, exists, absent);
	}

	public static void prepareAndAccessResult(final String query, final StatementPreparement prepping, final ResultAccessing use) {
		Database.useConnection(c -> {
			try (PreparedStatement ps = c.prepareStatement(query)) {
				prepping.prep(ps);
				try (ResultSet rs = ps.executeQuery()) {
					use.access(rs);

				}
			} catch (SQLException e) {
				e.printStackTrace();

			}
		});
	}

	public static void prepareAndGetInt(final String query, final StatementPreparement prepping, final IntResultParsing parsing, final Consumer<OptionalInt> resultTask) {
		Database.doRetrieval(c -> {
			try (PreparedStatement ps = c.prepareStatement(query)) {
				prepping.prep(ps);
				try (ResultSet rs = ps.executeQuery()) {
					if (rs.next()) {
						return OptionalInt.of(parsing.parseToInt(rs));

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();

			}
			return OptionalInt.empty();
		}, resultTask);
	}

	public static <T> void prepareAndRetrieve(final String query, final StatementPreparement prepping, final ResultParsing<Optional<T>> parsing, final Consumer<Optional<T>> resultTask) {
		Database.doRetrieval(c -> {
			try (PreparedStatement ps = c.prepareStatement(query)) {
				prepping.prep(ps);
				try (ResultSet rs = ps.executeQuery()) {
					if (rs.next()) {
						return parsing.parse(rs);

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();

			}
			return Optional.empty();
		}, resultTask);
	}

	public static void prepareAndStackInts(final String query, final StatementPreparement prepping, final IntResultParsing parsing, final Consumer<IntStream> resultTask) {
		Database.doRetrieval(c -> {
			IntStream.Builder sb = IntStream.builder();
			try (PreparedStatement ps = c.prepareStatement(query)) {
				prepping.prep(ps);
				try (ResultSet rs = ps.executeQuery()) {
					while (rs.next()) {
						sb.accept(parsing.parseToInt(rs));

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();

			}
			return sb.build();
		}, resultTask);
	}

	public static <T> void prepareAndStack(final String query, final StatementPreparement prepping, final ResultParsing<T> parsing, final Consumer<Stream<T>> resultTask) {
		Database.doRetrieval(c -> {
			Stream.Builder<T> sb = Stream.builder();
			try (PreparedStatement ps = c.prepareStatement(query)) {
				prepping.prep(ps);
				try (ResultSet rs = ps.executeQuery()) {
					while (rs.next()) {
						sb.accept(parsing.parse(rs));

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();

			}
			return sb.build();
		}, resultTask);
	}
}
