package net.snowstroem.lumisota.sql;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResultEvaluation {
	boolean evaluate(ResultSet rs) throws SQLException;
}
