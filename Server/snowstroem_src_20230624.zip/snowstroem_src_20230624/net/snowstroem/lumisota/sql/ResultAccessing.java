package net.snowstroem.lumisota.sql;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResultAccessing {
	public void access(ResultSet rs) throws SQLException;
}
