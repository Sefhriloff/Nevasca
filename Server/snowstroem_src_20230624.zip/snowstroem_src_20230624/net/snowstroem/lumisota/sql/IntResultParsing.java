package net.snowstroem.lumisota.sql;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface IntResultParsing {
int parseToInt(ResultSet rs) throws SQLException;
}
