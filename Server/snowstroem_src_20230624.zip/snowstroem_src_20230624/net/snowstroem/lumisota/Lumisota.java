package net.snowstroem.lumisota;

import static java.util.concurrent.Executors.newScheduledThreadPool;
import static java.util.stream.Collectors.joining;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import net.snowstroem.lumisota.chatlogger.ChatLogging;
import net.snowstroem.lumisota.fuse.FuseServer;
import net.snowstroem.lumisota.fuse.FuseServerManager;
import net.snowstroem.lumisota.fuse.ListenerCall;
import net.snowstroem.lumisota.parsing.ContentParsers;
import net.snowstroem.lumisota.remote.UDPQueryHandler;
import net.snowstroem.lumisota.sql.Database;
import net.snowstroem.lumisota.sql.NewDatabase;
import net.snowstroem.lumisota.users.UserRegistry;

/**
 * Project Snowström! main thread
 *
 */
public final class Lumisota {
	private static final Queue<String> COTTAGE_NAMES = new ArrayDeque<>(32);
	private static int BOOT_COTTAGES;
	private static final byte[] REMOTE_SECRET;
	private static final String REMOTE_BIND;
	private static final int REMOTE_PORT;
	public static final SecureRandom RNG;
	public static final ScheduledExecutorService SCHEDULER;
	public static final String DOMAIN;
	public static final int LANDSCAPE_PORT, SCHEDULER_CORES;
	public static final int[] COTTAGE_PORTS;

	static {
		LumisotaConfig.create();
		final Map<String, String> props = ContentParsers.kvFileToMap(LumisotaConfig.LS_CONF_P);
		Collections.addAll(COTTAGE_NAMES, props.get("cottageNames").split(","));
		DOMAIN = props.getOrDefault("cottageDomain", "127.0.0.1");
		REMOTE_SECRET = props.getOrDefault("remoteSecret", "").getBytes(StandardCharsets.UTF_8);
		REMOTE_BIND = props.getOrDefault("remoteBind", "127.0.0.1");
		REMOTE_PORT = Integer.parseInt(props.getOrDefault("remotePort", "51000"));
		LANDSCAPE_PORT = Integer.parseInt(props.getOrDefault("landscapePort", "51001")); // default port (51001) by dcr
		COTTAGE_PORTS = Stream.of(props.getOrDefault("cottagePorts", "51002-51031").split(","))
		.flatMapToInt(p -> {
			if (p.indexOf('-') > 0) {
				final String[] pr = p.split("-");
				return pr.length < 2
						? IntStream.of(Integer.parseInt(p.substring(0, p.indexOf('-'))))
								: IntStream.rangeClosed(Integer.parseInt(pr[0]), Integer.parseInt(pr[1]));

			}
			return IntStream.of(Integer.parseInt(p));
		})
		.limit(30)
		.toArray();
		SCHEDULER_CORES = Integer.parseInt(props.getOrDefault("schedulerCores", "2"));
		BOOT_COTTAGES = Integer.parseInt(props.getOrDefault("cottagesOnBoot", "1"));
		RNG = new SecureRandom();
		SCHEDULER = newScheduledThreadPool(SCHEDULER_CORES);

	}

	public static void main(String[] args) {
		Database.useConnection(c -> {
			try {
				NewDatabase.create(c);
				System.out.println("Connected to SQL successfully");

			} catch (NullPointerException | SQLException e) {
				e.printStackTrace();
				System.err.println("Database not initialized, shutting down");
				System.exit(1);

			}
		});

		SCHEDULER.scheduleWithFixedDelay(ChatLogging::flushQueue, 10, 10, TimeUnit.MINUTES); // Chat writer
		FuseServerManager.startNewServer("ENTERPRISESERVER"); // Boot landscape, should end up at index 0
		BOOT_COTTAGES = Math.max(1, Math.min(BOOT_COTTAGES, COTTAGE_PORTS.length)); // Limit cottage count to client limits and available ports
		while (BOOT_COTTAGES-- > 0) {
			FuseServerManager.startNewServer(COTTAGE_NAMES.poll());

		}
		Runtime.getRuntime().addShutdownHook(new Thread(ChatLogging::flushQueue));
		UDPQueryHandler.process(REMOTE_BIND, REMOTE_PORT, REMOTE_SECRET);

	}

	public static String handleQuery(final byte cmd, final String data) {
		switch (cmd) {
		case 'A': { // Announce
			if (data.length() > 0) {
				final byte[] notice = new ListenerCall("SYSTEMBROADCAST", data).toBytes();
				FuseServerManager.servers(false).forEach(s -> s.announce(notice));
				System.out.println("UDP: passed on an announcement");

			}
			return "OK";

		} case 'N': { // New cottage
			final byte n = FuseServerManager.startNewServer(data.length() > 0 ? data : COTTAGE_NAMES.poll());
			System.out.println("UDP: booted cottage " + FuseServerManager.HOSTS[n].serverName);
			return "OK";

		} case 'C': { // Close cottage
			if (data.length() > 0) {
				FuseServerManager.closeCottage(data);
				COTTAGE_NAMES.add(data);
				System.out.println("UDP: closed cottage " + data);
				return "OK";

			}
			return "NO";

		} case 'L': { // List cottages
			return FuseServerManager.servers(true)
					.map(c -> c.serverName)
					.collect(joining("/"));

		} case 'K': { // Remove client
			if (data.length() > 0) {
				FuseServerManager.servers(false)
				.forEach(s -> s.removeClient(data));
				System.out.println("UDP: disconnected " + data);

			}
			return "OK";

		} case 'D': { // Delete account
			if (data.length() > 0) {
				UserRegistry.tryDelete(data);
				System.out.println("UDP: deleted account " + data);

			}
			return "OK";

		} case 'U': { // Player count
			return Integer.toString(FuseServerManager.servers(false)
					.mapToInt(FuseServer::authsSize)
					.sum());

		} case 'X': { // Set Xtras
			final int len = data.length();
			if (len > 3) {
				Database.useConnection(conn -> {
					UserRegistry.setXtras(data.substring(0, len - 3), data.charAt(len - 3) == '1', data.charAt(len - 2) == '1', data.charAt(len - 1) == '1');

				});
				System.out.println("UDP: set account bonuses; " + data);
			}
			return "OK";

		}
		default: return "NO";

		}
	}
}
