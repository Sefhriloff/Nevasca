package net.snowstroem.lumisota.fuse;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.Map;
import java.util.OptionalInt;
import java.util.function.BiConsumer;

import net.snowstroem.lumisota.areas.Area;
import net.snowstroem.lumisota.areas.LobbyArea;
import net.snowstroem.lumisota.areas.entities.AreaClient;
import net.snowstroem.lumisota.net.RecvDataLoop;
import net.snowstroem.lumisota.net.SendDataLoop;
import net.snowstroem.lumisota.parsing.ContentParsers;
import net.snowstroem.lumisota.users.Player;

/**
 * A handler of TCP connection between Lumisota client and the server
 *
 */
public class Client {
	private final SendDataLoop out;
	private final RecvDataLoop parseLen;
	private final RecvDataLoop parseMsg;
	public final FuseServer host;
	public final int sum;

	public Map<String, BiConsumer<Client, String>> mode;
	/**
	 * Contains User once authenticated, otherwise null
	 */
	public Player identity;
	public Area venue;
	public AreaClient avatar;
	public boolean vOk = false;


	public Client(AsynchronousSocketChannel asc, FuseServer srv, int cSum) {
		host = srv;
		out = new SendDataLoop(asc);
		final ByteBuffer in = ByteBuffer.allocate(1024);
		parseLen = new RecvDataLoop(asc, in, this::completeLengthRead);
		parseMsg = new RecvDataLoop(asc, in, this::completeMessageRead);
		identity = null;
		mode = FuseComms.initHandlers();
		sum = cSum;

	}

	public void queueCall(final byte[] bytes) {
		out.send(ByteBuffer.wrap(bytes));

	}

	public void queueCall(final CharSequence l) {
		out.send(ContentParsers.chrsToBuffer(l));

	}

	private void completeLengthRead(final ByteBuffer b) {
		b.rewind();
		int msgLen = 0;
		while (b.hasRemaining()) {
			final byte n = b.get();
			if (n <= '9' && n >= '0') msgLen = msgLen * 10 + (n - '0');
		}

		if (msgLen <= 1024) {
			parseMsg.init(msgLen, this, 10L);

		} else { // TL;DR
			System.out.println("Terminating Client on ".concat(getIp()).concat(" by long input"));
			host.removeClient(this);
		}
	}

	private void completeMessageRead(final ByteBuffer b) {
		FuseComms.handleMessage(this, new String(b.array(), 0, b.limit(), ContentParsers.CHARSET));
		run();

	}

	public void close() {
		out.kill();

	}

	public String getIp() {
		return out.getIp();

	}

	public void run() {
		if (out.up()) {
			parseLen.init(4, this, 100L);

		} else {
			host.removeClient(this);

		}
	}

	public void setVenue(Area v, boolean alt, boolean redTeam, OptionalInt rank) {
		venue = v;
		avatar = venue.enterUser(this, alt, redTeam, rank);
		mode = (venue instanceof LobbyArea ? FuseComms.HANDLERS_LOBBY : FuseComms.HANDLERS_GAME);

	}
}
