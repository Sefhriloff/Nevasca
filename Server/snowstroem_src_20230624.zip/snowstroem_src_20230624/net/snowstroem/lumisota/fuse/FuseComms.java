package net.snowstroem.lumisota.fuse;

import java.util.Map;
import java.util.function.BiConsumer;

import net.snowstroem.lumisota.chatlogger.ChatLogging;
import net.snowstroem.lumisota.chatlogger.ChatlogEntry;
import net.snowstroem.lumisota.parsing.ContentParsers;
import net.snowstroem.lumisota.users.UserRegistry;

/**
 * FuseComms contains all known incoming messages and some error responses
 *
 */
final class FuseComms {
	private final static byte WHISPER_T = 0, SAY_T = 1, SHOUT_T = 2;
	private final static byte[]
			E_FULL = {'#','E','R','R','O','R',13,
					'c','o','t','t','a','g','e',' ','f','u','l','l','#','#'},
			E_VCHECK = {'#','E','R','R','O','R',13,
					'v','e','r','s','i','o','n',' ','n','o','t',' ','c','o','r','r','e','c','t','#','#'},
			E_AUTH = {'#','E','R','R','O','R',13,
					'l','o','g','i','n',' ','i','n','#','#'},
			E_DUPE = {'#','E','R','R','O','R',13,
					'u','s','e','r',' ','a','l','r','e','a','d','y','#','#'};

	private final static BiConsumer<Client, String> NO_OP = (c, m) -> {
		// No operation
	};

	final static Map<String, BiConsumer<Client, String>>
	HANDLERS_UPDATE = Map.of(
			"UPDATE", (c, m) -> {
				UserRegistry.updateUser(ContentParsers.kvToMap(m), c.identity.id);
				c.host.removeClient(c);
			}
			),

	HANDLERS_LANDSCAPE = Map.of(
			"GETUNITUSERS", (c, m) -> {
				c.queueCall(FuseServerManager.getClients(m));
			},

			"FINDUSER", UserRegistry::findUser
			),

	HANDLERS_LOBBY = Map.of(
			"Move", (c, m) -> {
				final String[] xy = ContentParsers.getParamPair(m);
				if (xy.length == 2) {
					byte x2, y2;
					try {
						x2 = Byte.parseByte(xy[0]);
						y2 = Byte.parseByte(xy[1]);
					} catch (NumberFormatException nfe) {
						return;
					}
					c.venue.move(c.avatar, x2, y2);
				}
			},

			"LOOKTO", (c, m) -> {
				final String[] xy = ContentParsers.getParamPair(m);
				byte atX, atY;
				try {
					atX = Byte.parseByte(xy[0]);
					atY = Byte.parseByte(xy[1]);
				} catch (NumberFormatException nfe) {
					atX = atY = 0;
				}
				c.avatar.lookTo(atX, atY);
			},

			"CHAT", (c, m) -> {
				final String input = FuseFilter.limitChat(m);
				c.venue.chat(c.avatar, false, null, input);
				ChatLogging.addEntry(new ChatlogEntry(c.identity.id, SAY_T, input));
			},

			"SHOUT", (c, m) -> {
				final String input = FuseFilter.limitChat(m);
				c.venue.chat(c.avatar, true, null, input);
				ChatLogging.addEntry(new ChatlogEntry(c.identity.id, SHOUT_T, input));
			},

			"WHISPER", (c, m) -> {
				final String[] msg = ContentParsers.getParamPair(m);
				if (msg.length == 2) {
					final String input = FuseFilter.limitChat(msg[1]);
					c.venue.chat(c.avatar, false, msg[0], input);
					ChatLogging.addEntry(new ChatlogEntry(c.identity.id, WHISPER_T, input));
				}
			},

			"JoinGame", (c, m) -> {
				c.venue.joinGameEvent(c.avatar, m);
			},

			"CreateGame", (c, m) -> {
				c.venue.makeGameEvent(c.avatar, m);
			},

			"StartGame", (c, m) -> {
				c.venue.beginGameEvent(c.avatar, m);
			},

			"UndoGame", (c, m) -> {
				c.venue.disposeGameEvent(c.avatar, m);
			}
			),

	HANDLERS_GAME = Map.of(
			"Move", HANDLERS_LOBBY.get("Move"),

			"LOOKTO", HANDLERS_LOBBY.get("LOOKTO"),

			"CHAT", HANDLERS_LOBBY.get("CHAT"),

			"SHOUT", HANDLERS_LOBBY.get("SHOUT"),

			"WHISPER", HANDLERS_LOBBY.get("WHISPER"),

			"MakeSnowball", HANDLERS_LOBBY.get("CreateGame"), // Accesses SnowfightArea's makeGameEvent()

			"ThrowSnowball", HANDLERS_LOBBY.get("UndoGame"), // Accesses SnowfightArea's disposeGameEvent()

			"ReturnToLobby", (c, m) -> {
				c.avatar.transferTo(c.host.lobby, false);
			},

			"StopGame", (c, m) -> {
				c.avatar.transferTo(c.host.lobby, false);
			}
			),

	HANDLERS_AUTH = Map.of(
			"REGISTER", (c, m) -> {
				if (c.host.isLandscape && c.vOk) {
					UserRegistry.registerUser(c, ContentParsers.kvToMap(m), () -> clientError(c, E_DUPE));

				}
			},

			"LOGIN", (c, m) -> {
				if (c.vOk) {
					c.mode = HANDLERS_LANDSCAPE; // Deny further authentication requests, the client will disconnect on receiving incorrect details
					String[] credentials = ContentParsers.getParamPair(m);
					if (c.identity == null && credentials.length == 2) {
						UserRegistry.authenticate(credentials[0], credentials[1], o -> o.ifPresentOrElse(u -> {
							c.identity = u;
							if (c.host.isLandscape) {
								c.queueCall(FuseServerManager.listCottages());
								UserRegistry.writeAccessEntry(u.id, c.getIp());

							} else {
								if (c.host.authsSize() >= 25) {
									clientError(c, E_FULL);
									return;

								}
								UserRegistry.findRank(u.score, r -> {
									c.setVenue(c.host.lobby, false, false, r);
									FuseServerManager.HOSTS[0].announce(new ListenerCall("UNITUPDATED").append(c.host.cottageString()).toBytes());

								});
							}
							UserRegistry.updateStats(u); // Refresh last active timing

						}, () -> clientError(c, E_AUTH)));
					} else {
						clientError(c, E_AUTH);

					}
				}
			},

			"INFORETRIEVE", (c, m) -> {
				if (c.host.isLandscape && c.vOk) {
					c.mode = HANDLERS_UPDATE; // Deny further authentication attempts, see LOGIN
					String[] credentials = ContentParsers.getParamPair(m);
					if (c.identity == null && credentials.length == 2) {
						UserRegistry.authenticate(credentials[0], credentials[1], o -> o.ifPresentOrElse(u -> {
							c.identity = u;
							c.queueCall(u.userObject());
							UserRegistry.writeAccessEntry(u.id, c.getIp());

						}, () -> clientError(c, E_AUTH)));

					} else {
						clientError(c, E_AUTH);

					}
				}
			}
			),

	HANDLERS_INIT = Map.of(
			"KEYENCRYPTED", (c, m) -> {
				try {
					if (Integer.parseInt(m) == c.sum) {
						c.vOk = true;

					} else {
						clientError(c, E_VCHECK);

					}
				} catch (NumberFormatException nfe) {
					clientError(c, E_VCHECK);

				}
			},

			"VERSIONCHECK", (c, m) -> {
				if (!m.equals("v20000308_SMS")) {
					clientError(c, E_VCHECK);

				}
			},

			"CLIENTIP", (c, m) -> { // Garbage input "MacromediaSecretIpAddressCookie" or LAN address; discarded
				if (c.vOk) {
					c.mode = HANDLERS_AUTH;

				}
			}
			);

	private FuseComms() {}

	public static Map<String, BiConsumer<Client, String>> initHandlers() {
		return HANDLERS_INIT;

	}

	private static void clientError(final Client client, final byte[] error) {
		client.queueCall(error);
		System.out.println("Closing connection from " + client.getIp());
		client.host.removeClient(client);

	}

	static void handleMessage(Client client, String msg) {
		final String[] data = ContentParsers.getParamPair(msg);
		try {
			client.mode.getOrDefault(data[0], NO_OP).accept(client, data.length == 2 ? data[1] : "");

		} catch (Exception e) {
			System.err.println("Could not complete message handling");
			e.printStackTrace();

		}
	}
}
