package net.snowstroem.lumisota.fuse;

import static java.util.Collections.synchronizedList;
import static net.snowstroem.lumisota.fuse.FuseFilter.secretDecode;

import java.io.IOException;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import net.snowstroem.lumisota.Lumisota;
import net.snowstroem.lumisota.areas.LobbyArea;
import net.snowstroem.lumisota.areas.SnowfightArea;
import net.snowstroem.lumisota.net.AcceptClientLoop;
import net.snowstroem.lumisota.parsing.ContentParsers;

/**
 * A landscape or cottage server that manages all clients connected to it
 *
 */
public final class FuseServer{
	public final boolean isLandscape;
	public final LobbyArea lobby;
	private final SnowfightArea[] games;
	private final List<Client> connections;
	private final AcceptClientLoop clientInit;
	private ScheduledFuture<?> pingTask;

	public final String serverName;

	FuseServer(final String name, final int port) throws IOException {
		isLandscape = name == "ENTERPRISESERVER"; // Interned string check to ensure no cottage attempts to become landscape by naming it ENTERPRISESERVER
		serverName = name.intern();
		connections = synchronizedList(new ArrayList<>(30));
		clientInit = new AcceptClientLoop(port, this::addClient);
		if (isLandscape) {
			lobby = null;
			games = null;

		} else {
			lobby = new LobbyArea(this);
			games = new SnowfightArea[25];
			FuseServerManager.HOSTS[0].announce(new ListenerCall("NEWUNIT", cottageString()).toBytes());

		}
	}

	public void announce(final byte[] msg) {
		connections.forEach(c -> c.queueCall(msg));

	}

	public int authsSize() {
		synchronized (connections) {
			return getAuths().mapToInt(u -> 1).sum();

		}
	}

	public void closeArea(byte id) {
		if (id == -1) {
			lobby.shutdown();

		} else if (games[id] != null) {
			games[id].shutdown();
			games[id] = null;
			lobby.broadcast(lobby.drawGameboard());

		}
	}

	void closeServer() {
		if (!isLandscape) { // May only close cottages
			if (pingTask != null) {
				pingTask.cancel(false);

			}
			connections.forEach(Client::close);
			FuseServerManager.HOSTS[0].announce(new ListenerCall("UNITREMOVE", Integer.toString(this.hashCode(), 20)).toBytes());
			clientInit.kill();

		}
	}

	public String cottageString() {
		return Integer.toString(this.hashCode(), 20) + "," + authsSize() + ",25," + Lumisota.DOMAIN + "," + clientInit.getPort() + ',' + serverName;

	}

	public Stream<Client> getAuths() {
		return connections.stream().filter(c -> c.identity != null);

	}

	public Stream<SnowfightArea> getGames() {
		return Stream.of(games).filter(Objects::nonNull);

	}

	public Optional<SnowfightArea> getGame(final String name) {
		return getGames().filter(a -> a.name.equals(name)).findAny();

	}

	public void newGame(final String name, final byte minutes, final byte bots, final String owner, boolean redTeam) {
		byte id = 0;
		while (games[id] != null) id++;
		if (id < 25) {
			games[id] = new SnowfightArea(this, id, name, Lumisota.RNG.nextBoolean() ? 3 : 4, minutes, bots, owner, redTeam); //map3=lumisota2, 4=lumisota3
			return;

		}
	}

	public boolean hasUser(final int uId) {
		synchronized(connections) {
			return getAuths().map(c -> c.identity).anyMatch(u -> u.id == uId);

		}
	}

	/**
	 * Terminates socket channel and optionally announces removal from Area.
	 * @param client The Client to be killed
	 */
	private void killClient(final Client client) {
		client.close();
		if (!isLandscape && client.identity != null) {
			lobby.disposeGameEvent(client.avatar, null);
			Stream.concat(Stream.of(lobby), Stream.of(games)).filter(Objects::nonNull)
			.forEach(a -> a.leavingUser(client.identity.username, false));
			FuseServerManager.HOSTS[0].announce(new ListenerCall("UNITUPDATED", cottageString()).toBytes());
		}
	}

	private static byte[] newKey() {
		final int msgLen = 14 + (Lumisota.RNG.nextInt(8) + 12) * 2;
		byte[] msg = new byte[msgLen];
		msg[0] = msg[msgLen - 1] = msg[msgLen - 2] = '#';
		msg[2] = msg[5] = msg[9] = 'E';
		msg[1] = 'S';
		msg[3] = 'C';
		msg[4] = 'R';
		msg[6] = 'T';
		msg[7] = '_';
		msg[8] = 'K';
		msg[10] = 'Y';
		msg[11] = 0x0D;
		for (int i = msgLen - 3; i > 11; i--) {
			msg[i] = (byte) (Lumisota.RNG.nextInt(0x55) + 0x2A);

		}
		return msg;

	}

	public void removeClient(String username) {
		synchronized (connections) {
			getAuths().filter(u -> u.identity.username.equalsIgnoreCase(username)).findAny().ifPresent(this::removeClient);

		}
	}

	public void removeClient(Client client) {
		if (connections.remove(client)) {
			killClient(client);

		}
	}

	public void boot() {
		if (isLandscape) {
			final byte[] ping = new byte[] {'#', 'S', 'T', 'A', 'T', 'U', 'S', '\r', '#', '#'};
			Lumisota.SCHEDULER.scheduleWithFixedDelay(() -> {
				synchronized(connections) {
					getAuths().forEach(c -> c.queueCall(ping));

				}
			}, 100, 60, TimeUnit.SECONDS);
		}
		clientInit.init();

	}

	public void addClient(AsynchronousSocketChannel ch) {
		final byte[] key = newKey();
		final int sum = secretDecode(new String(Arrays.copyOfRange(key, 12, key.length - 2), ContentParsers.CHARSET));
		final Client client = new Client(ch, this, sum);
		connections.add(client); // SynchronizedList
		client.queueCall(key);
		client.run();

	}
}
