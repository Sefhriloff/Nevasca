package net.snowstroem.lumisota.fuse;

import net.snowstroem.lumisota.parsing.ContentParsers;

/**
 * A FUSE protocol message, StringBuilder wrapper
 *
 */
public class ListenerCall {
	private final static char ITEMD = '#', // Item delimiter
			CR = 0x0d, // Carriage Return
			WS = ' '; // White Space, common argument separator
	private final StringBuilder item;

	/**
	 * Constructs a ListenerCall with the starting item marker
	 */
	private ListenerCall() {
		item = new StringBuilder().append(ITEMD);

	}

	/**
	 * Constructs a ListenerCall with packet header
	 * @param header message content handler identifier such as STATUS, CHAT, UNITS...
	 */
	public ListenerCall(final String header) {
		this();
		initialize(header);

	}

	/**
	 * Constructs a ListenerCall with initial message content
	 * @param header
	 * @param output
	 */
	public ListenerCall(final String header, final String output) {
		this(header);
		item.append(output);

	}

	/**
	 * Resets ListenerCall's message head
	 * @param header The new message head
	 */
	public void initialize(final String header) {
		item.setLength(1); // Leave only the initial item marker
		item.append(header).append(CR);

	}

	/**
	 * Appends given String into ListenerCall's content
	 * @param s Content to append
	 * @return self
	 */
	public ListenerCall append(final CharSequence s) {
		item.append(s);
		return this;

	}

	/**
	 * Appends given integer into ListenerCall's content
	 * @param i number to append
	 * @return self
	 */
	public ListenerCall append(final int i) {
		item.append(i);
		return this;

	}

	public ListenerCall appendChr(char c) {
		item.append(c);
		return this;

	}

	/**
	 * Append given integer casted to char into ListenerCall's content
	 * @param i character code point to append
	 * @return self
	 */
	public ListenerCall appendChr(final int i) {
		return appendChr((char) i);

	}

	/**
	 * Appends a FUSE line separator, the Carriage Return, into ListenerCall's content
	 * @return self
	 */
	public ListenerCall cr() {
		return appendChr(CR);

	}

	/**
	 * Appends an argument separator, space bar, into ListenerCall's content
	 * @return self
	 */
	public ListenerCall ws() {
		return appendChr(WS);

	}

	public byte[] toBytes() {
		return ContentParsers.chrsToBuffer(item.append(ITEMD).append(ITEMD)).array();

	}

	public void sendTo(final Client c) {
		c.queueCall(item.append(ITEMD).append(ITEMD));

	}
}
