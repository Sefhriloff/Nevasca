package net.snowstroem.lumisota.fuse;

import java.util.regex.Pattern;

/**
 * Security functions against abusive clients
 *
 */
public final class FuseFilter {
	private final static int CHATINPUT_MAX = 140;
	private final static Pattern FIGURE_REGEX = Pattern.compile("^[1-68-9],[1-6],1$");

	private FuseFilter() {}
	/**
	 * Filters bad chars from input
	 * @param input The client-provided data to filter
	 * @param inclWhiteSpace True when spaces should not be tolerated
	 * @return filtered input
	 */
	public static String filterInput(String input, boolean inclWhiteSpace) {
		return input == null ? "" : input.codePoints()
				.filter(p -> p > (inclWhiteSpace ? 0x20 : 0x1F)) // code points less or equal to this will be removed
				.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
				.toString();

	}

	public static String filterFigure(String fig) {
		return fig != null && FIGURE_REGEX.matcher(fig).matches() ? fig : "1,1,1";

	}

	public static String limitChat(final String chat) {
		return chat.length() > CHATINPUT_MAX ? chat.substring(0, CHATINPUT_MAX) : chat;

	}

	public static int secretDecode(final String secretKey) {
		final int keyTableLen = secretKey.length() / 2, mod2 = keyTableLen % 2;
		final String key = secretKey.substring(keyTableLen).toLowerCase(), table = secretKey.substring(0, keyTableLen).toLowerCase();
		int a, sum = 0;
		for (int i = 0; i < keyTableLen; i++) {
			a = table.indexOf(key.charAt(i));
			if (a % 2 == 0) {
				a *= 2;

			}
			if (i % 3 == 0) {
				a *= 3;

			}
			if (a < 0) {
				a = mod2;

			}
			sum += a;

		}
		return sum;

	}
}
