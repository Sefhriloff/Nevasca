package net.snowstroem.lumisota.fuse;

import static java.util.Arrays.stream;
import static net.snowstroem.lumisota.parsing.ContentParsers.toFuseListener;

import java.io.IOException;
import java.util.Objects;
import java.util.stream.Stream;

import net.snowstroem.lumisota.Lumisota;

/**
 * Container class for the Landscape server and Cottage servers.
 *
 */
public final class FuseServerManager {
	public static final FuseServer[] HOSTS = new FuseServer[1 + Lumisota.COTTAGE_PORTS.length];

	public static void closeCottage(final String name) {
		for (int s = 1; s < HOSTS.length; s++) {
			if (HOSTS[s] != null && name.equalsIgnoreCase(HOSTS[s].serverName)) {
				HOSTS[s].closeServer();
				HOSTS[s] = null;
				return; // End array traversal
			}
		}
	}

	public static String getClients(final String name) {
		return servers(true)
				.filter(s -> s.serverName.equals(name))
				.flatMap(FuseServer::getAuths)
				.map(c -> c.identity.username)
				.collect(toFuseListener("UNITMEMBERS"));
	}

	public static Stream<FuseServer> servers(boolean cottagesOnly) {
		return stream(HOSTS, cottagesOnly ? 1 : 0, HOSTS.length).filter(Objects::nonNull);
	}

	public static String listCottages() {
		return servers(true)
				.map(FuseServer::cottageString)
				.collect(toFuseListener("ALLUNITS"));
	}

	public static String locateClient(final int uId) {
		for (FuseServer server : HOSTS) {
			if (server != null && server.hasUser(uId)) return server.serverName;
		}
		return "";
	}

	public static byte startNewServer(final String name) {
		byte id = 0;
		while (HOSTS[id] != null) {
			if (++id > HOSTS.length) {
				return -1; // Increment up to array capacity, then cancel if full

			}
		}
		try {
			(HOSTS[id] = new FuseServer(name == null ? ("M\u00f6kki " + id) : name, Lumisota.LANDSCAPE_PORT + id)).boot();
			return id;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return -1;
	}
}
