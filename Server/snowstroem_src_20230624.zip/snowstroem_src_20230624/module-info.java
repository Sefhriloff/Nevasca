
module net.snowstroem.lumisota {
	exports net.snowstroem.lumisota;

	requires java.sql;
	requires com.h2database;
}
